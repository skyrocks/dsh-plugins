# 发布清单（维护者用）

这份文件随 tarball 发布，但只用于把仓库整理成可公开的状态。

## 1. 检查

```sh
node --test test/context.test.mjs test/handoff.test.mjs test/client.test.mjs
node test/manifest.mjs
node --check index.js client.js context.js handoff.js typert.host.js
```

## 2. 发布到 GitHub

仓库根目录就是**本目录的内容**（`package.json` 与 `cordis.patch.yml` 在根），
不要把外层父目录一起上传，否则 `github:skyrocks/dsh-session-handoff` 安装会找不到插件清单。

```sh
git push git@github.com:skyrocks/dsh-session-handoff.git main
git tag -a v<版本> -m "v<版本>"
git push git@github.com:skyrocks/dsh-session-handoff.git v<版本>
```

本机 github.com:443 不通时用 SSH（`git@github.com:`），不要造分叉提交。

## 3. 打包并挂 Release

```sh
/Users/shilei/PrivateCode/dsh/.tools/pnpm pack --pack-destination ../dsh-plugins/dist
gh release create v<版本> --repo skyrocks/dsh-session-handoff --title "v<版本>" \
  --notes-file <说明文件> ../dsh-plugins/dist/skyrocks-dsh-session-handoff-<版本>.tgz
```

替代方式：`gh api repos/skyrocks/dsh-session-handoff/releases` 手工建 Release 并上传同一个 tgz。

## 4. 进 dsh-plugins 索引

在 `dsh-plugins/index.json` 加/改版本条目（`source.commit` 必须是已推送到 GitHub 的 40 位 commit）、
同步两份 README 的安装命令，然后：

```sh
node scripts/check-index.mjs     # 必须通过
git add -A && git commit -m "index: sync dsh-session-handoff <版本>"
node ../.tools/gh-push.mjs skyrocks/dsh-plugins dsh-plugins main
```

## 5. 投稿收录站

在 `polang233/dsh-plugin-index` 开一个 issue，写清包名、版本、40 位 commit、仓库地址与一句话说明；
后续同一插件的新版本直接在该 issue 里回帖，不要重复开新 issue。

## 6. 发布前检查

- [ ] 三套测试与 `node test/manifest.mjs` 通过
- [ ] 包内 `files` 不含 `test`（自动化商店会把测试里的 `node:fs` 判成 files 权限信号）
- [ ] `package.json` 含 `repository` / `homepage` / `bugs`
- [ ] tag、Release、tgz、索引 pin 四者指向同一个 commit
- [ ] 装好后点一次「发送到会话」，确认目标会话真的开跑
