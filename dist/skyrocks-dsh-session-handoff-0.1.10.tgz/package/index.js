// Host 半：会话交接。
//
// 这个文件只做三件事：接服务、校验配置、把调用转给 handoff.js。真正的编排在 handoff.js，
// 它不依赖 Cordis 上下文，因此可以用假服务单测。
//
// 读历史走 ctx.sessionQuery，建会话 / 投递走 ctx.sessionController，摘要走 ctx.llm，
// 工作区分组走 ctx.workspaceRegistry —— 全是当前组合里已挂载的公开服务，
// 插件不碰任何私有存储，会话日志仍然是唯一事实来源。
import z from "@deepseek-ai/schemastery";
import { TypertRemoteService } from "@deepseek-ai/dsh-typert-protocol";

import { createTarget, listTargets, listTitles, sendHandoff } from "./handoff.js";

const DEFAULT_RECENT_TURNS = 3;
const DEFAULT_SUMMARY_MAX_CHARS = 1200;
const DEFAULT_SUMMARY_INPUT_CHARS = 8000;
const DEFAULT_WINDOW_MESSAGES = 60;
const DEFAULT_SUMMARIZE_THRESHOLD = 1200;
const DEFAULT_VERBATIM_MAX_CHARS = 12000;

export const Config = z.object({
  /** 原文保留最近几轮。 */
  recentTurns: z.natural().min(1).default(DEFAULT_RECENT_TURNS),
  /** 摘要的字数上限。 */
  summaryMaxChars: z.natural().min(200).default(DEFAULT_SUMMARY_MAX_CHARS),
  /** 送去摘要的原文上限，超出先截断再压缩。 */
  summaryInputChars: z.natural().min(1000).default(DEFAULT_SUMMARY_INPUT_CHARS),
  /** 只读源会话尾部的多少条消息（不再重放整份日志）。 */
  windowMessages: z.natural().min(10).default(DEFAULT_WINDOW_MESSAGES),
  /** 更早的原文超过这个长度才调模型压缩，短则原样带上。 */
  summarizeThreshold: z.natural().min(200).default(DEFAULT_SUMMARIZE_THRESHOLD),
  /** 最近几轮原文的字数上限。 */
  verbatimMaxChars: z.natural().min(1000).default(DEFAULT_VERBATIM_MAX_CHARS),
  /** 新建的会话是否按「来自：<源会话标题>」命名。 */
  nameNewSessions: z.boolean().default(true)
});

export class SessionHandoff extends TypertRemoteService {
  // sessionQuery 由 dsh-session-query-sqlite 提供；workspaceRegistry 由 dsh-workspace 提供；
  // sessionController 由 dsh-api-session-controller 提供。缺任何一个都说明组合不完整，
  // 此时插件保持未激活，而不是带着 undefined 崩在调用时。
  static inject = ["sessionController", "workspaceRegistry", "sessionQuery"];
  static Config = Config;

  constructor(ctx, config) {
    super(ctx, "sessionHandoff");
    this.config = config ?? {};
  }

  /** 每次调用现取服务：组合可能比插件更晚就绪。 */
  services() {
    return {
      sessionController: this.ctx.get("sessionController"),
      workspaceRegistry: this.ctx.get("workspaceRegistry"),
      sessionQuery: this.ctx.get("sessionQuery"),
      llm: this.ctx.get("llm"),
      agents: this.ctx.get("agents"),
      agentDefaultModel: this.ctx.get("agentDefaultModel"),
      logger: this.ctx.logger,
      signal: () => new AbortController().signal
    };
  }

  /** 列出全部工作区及其中的会话，供选择器分组展示。 */
  async targets() {
    return listTargets(this.services());
  }

  /** 给列表里还没有标题的会话补标题（冷会话要读日志才能折叠出标题）。 */
  async titles(request) {
    return listTitles(this.services(), request?.sessionIds);
  }

  /** 先建一个空会话，交给客户端切过去，再让 send 往里面投递。 */
  async create(request) {
    return createTarget(this.services(), request);
  }

  /** 把源会话的一段上下文投递到目标会话（不存在则新建），并让它接着跑。 */
  async send(request) {
    return sendHandoff(this.services(), this.config, request);
  }
}

export default SessionHandoff;
