// 会话交接的内容拼装：纯函数，不依赖任何 DSH 服务，便于单测。
//
// 输入是一份原始事件日志（sessionQuery.readSession 的 events）和用户点击的那条
// 助手消息 id；输出是「最近 N 轮的原文」+「更早部分的待摘要文本」。
//
// 几条取舍：
//   1. 只取人类的 user/message（source.kind === 'user'）和 assistant/message 的
//      文本块；agent.inject 注入的合成上下文、工具调用、工具结果一律不进交接包
//      —— 用户要的是「讨论」，不是整份日志。
//   2. 轮次按 turn/end 切，而不是按消息条数：一个 turn 里可能只有一句话，也可能
//      有十几次工具调用。
//   3. 找不到被点击的消息时退回日志末尾，绝不因为定位失败就整单失败。

const USER_KIND = "user";

/** 从 LLM 内容块里抽纯文本。 */
export function partsText(parts) {
  if (!Array.isArray(parts)) return "";
  const chunks = [];
  for (const part of parts) {
    if (part === null || typeof part !== "object") continue;
    if (part.type === "text" && typeof part.text === "string" && part.text.trim().length > 0) {
      chunks.push(part.text.trim());
    }
  }
  return chunks.join("\n").trim();
}

/** 一条事件如果携带人类可见的对话文本，返回 { role, text }；否则 null。 */
export function readUtterance(event) {
  if (event === null || typeof event !== "object") return null;
  if (event.type === "user/message") {
    const data = event.data ?? {};
    const source = data.source ?? {};
    if (source.kind !== USER_KIND) return null;
    const text = partsText(data.content);
    return text.length > 0 ? { role: "user", text } : null;
  }
  if (event.type === "assistant/message") {
    const message = event.data?.message ?? {};
    const text = partsText(message.content);
    if (text.length === 0) return null;
    if (event.data?.interrupted === true && text.length === 0) return null;
    return { role: "assistant", text };
  }
  return null;
}

/** 事件携带的消息 id（用户消息在 data.id，助手消息在 data.message.id）。 */
export function messageIdOf(event) {
  if (event === null || typeof event !== "object") return undefined;
  if (event.type === "user/message") return event.data?.id;
  if (event.type === "assistant/message") return event.data?.message?.id;
  return undefined;
}

/** 把正文压到不超过 maxChars，尽量在换行处截断。 */
export function clamp(text, maxChars) {
  if (typeof text !== "string") return "";
  if (maxChars <= 0 || text.length <= maxChars) return text;
  const head = text.slice(0, maxChars);
  const cut = head.lastIndexOf("\n");
  const body = cut > maxChars * 0.6 ? head.slice(0, cut) : head;
  return `${body.trimEnd()}\n…（后文已省略）`;
}

/**
 * 定位被点击的那条消息，并把它之前的对话切成「更早（待摘要）」和「最近 N 轮」。
 * @param {Array<{seq:number,type:string,data?:object}>} events 按 seq 升序的原始事件
 * @param {{ messageId?: string, recentTurns?: number, verbatimMaxChars?: number }} options
 * @returns {{ cutSeq:number|null, recentText:string, historyText:string,
 *             recentTurns:number, totalTurns:number, found:boolean }}
 */
export function splitConversation(events, options = {}) {
  const list = Array.isArray(events) ? events : [];
  const recentTurns = Number.isInteger(options.recentTurns) && options.recentTurns > 0 ? options.recentTurns : 3;
  const verbatimMaxChars = Number.isFinite(options.verbatimMaxChars) ? options.verbatimMaxChars : 12000;

  let cutSeq = null;
  let found = false;
  if (typeof options.messageId === "string" && options.messageId.length > 0) {
    for (const event of list) {
      if (messageIdOf(event) === options.messageId) {
        cutSeq = event.seq;
        found = true;
      }
    }
  }
  if (cutSeq === null) cutSeq = list.length > 0 ? list[list.length - 1].seq : null;

  const upto = list.filter((event) => cutSeq === null || event.seq <= cutSeq);

  // 轮次边界用 turn/start：用户点在最后一条回复上时，这一轮通常还没写出 turn/end，
  // 按 turn/end 数会把当前这轮漏掉。没有 turn/start 的旧日志再退回 turn/end。
  let turnStarts = [];
  for (const event of upto) {
    if (event.type === "turn/start") turnStarts.push(event.seq);
  }
  if (turnStarts.length === 0) {
    for (const event of upto) {
      if (event.type === "turn/end") turnStarts.push(event.seq);
    }
  }
  const totalTurns = turnStarts.length;
  const startSeq =
    turnStarts.length > recentTurns ? turnStarts[turnStarts.length - recentTurns] : Number.NEGATIVE_INFINITY;

  const recentLines = [];
  const historyLines = [];
  for (const event of upto) {
    const utterance = readUtterance(event);
    if (utterance === null) continue;
    const line = utterance.role === "user" ? `用户：${utterance.text}` : `助手：${utterance.text}`;
    if (event.seq >= startSeq) recentLines.push(line);
    else historyLines.push(line);
  }

  return {
    cutSeq,
    found,
    totalTurns,
    recentTurns: Math.min(recentTurns, totalTurns),
    recentText: clamp(recentLines.join("\n\n"), verbatimMaxChars),
    historyText: historyLines.join("\n\n")
  };
}

/** 交接包末尾的指令：先复述理解、不要动手，等人确认。 */
export const HANDOFF_INSTRUCTION =
  "请先不要动手。用要点复述你对这次交接的理解：要做什么、范围与约束是什么、已经完成了哪些、" +
  "你打算怎么开始。复述完就停下，等我的进一步指示；不要在这条回复里开始执行。";

/** 拼出最终发给目标会话的那条消息。 */
export function composeBundle({ sourceTitle, summary, recentText, summaryIsRaw = false, truncated = false }) {
  const sections = [];
  const from = typeof sourceTitle === "string" && sourceTitle.trim().length > 0 ? sourceTitle.trim() : "另一个会话";
  sections.push(`以下是「${from}」里的讨论，作为你接下来工作的上下文。`);
  if (typeof summary === "string" && summary.trim().length > 0) {
    const label = summaryIsRaw ? "## 更早的讨论（原文节选）" : "## 更早的讨论摘要";
    sections.push(`${label}\n${summary.trim()}`);
  }
  if (truncated === true) {
    sections.push("（更早的对话还有未包含的部分；需要细节就去问用户。）");
  }
  if (typeof recentText === "string" && recentText.trim().length > 0) {
    sections.push(`## 最近的对话\n${recentText.trim()}`);
  }
  sections.push(HANDOFF_INSTRUCTION);
  return sections.join("\n\n");
}

/** 摘要请求的提示词。 */
export const SUMMARY_SYSTEM_PROMPT =
  "你是对话整理助手。把用户提供的讨论压缩成要点摘要，保留：用户的目标与约束、已确认的结论与决定、" +
  "已经做过的改动、仍未解决的问题。用第三人称陈述，不要寒暄，不要编造没出现过的内容。控制在 800 字以内。";
