// Typert Host 清单：声明 sessionHandoff/{targets,send} 两个 direct 调用。
// 0.2.x 的 strict codec 形如 `{ mode, typeSymbol, create() }`；这里不依赖 zod，
// 目录直装不会缺包。校验刻意宽松：结果结构在 Host 侧已经定好，Client 只做展示。
const PACKAGE = "@skyrocks/dsh-session-handoff";

const isRecord = (value) => value !== null && typeof value === "object" && !Array.isArray(value);

function fail(field, expected) {
  throw new Error(`${PACKAGE} ${field}: 需要 ${expected}`);
}

function string(field, value) {
  if (typeof value !== "string") fail(field, "字符串");
  return value;
}

function codec(typeSymbol, parse) {
  return { mode: "strict", typeSymbol, create: () => ({ parse }) };
}

// typeSymbol 必须和客户端 REMOTE 描述符逐字一致（strict codec 按符号校验，
// 对不上时客户端会拿不到值，表现为「调用成功但返回 undefined」）。
const result = (name, parse) => codec(`${PACKAGE}#SessionHandoff${name}Result`, parse);
const parameter = (name, parse) => ({
  name,
  wire: name,
  source: "json",
  codec: codec(`${PACKAGE}#${name}`, parse)
});

function parseSendRequest(value) {
  if (!isRecord(value)) fail("send request", "对象");
  string("request.sourceSessionId", value.sourceSessionId);
  if (value.messageId !== undefined && value.messageId !== null) string("request.messageId", value.messageId);
  if (value.target !== undefined && value.target !== null) {
    if (!isRecord(value.target)) fail("request.target", "对象");
    if (value.target.kind !== "new" && value.target.kind !== "existing") fail("request.target.kind", "new 或 existing");
  }
  return value;
}

function parseTitlesRequest(value) {
  if (!isRecord(value)) fail("titles request", "对象");
  if (!Array.isArray(value.sessionIds)) fail("request.sessionIds", "数组");
  return value;
}

function parseTitlesResult(value) {
  if (!isRecord(value) || !isRecord(value.titles)) fail("titles result", "含 titles 对象的对象");
  return value;
}

function parseTargetsResult(value) {
  if (!isRecord(value) || !Array.isArray(value.groups)) fail("targets result", "含 groups 数组的对象");
  return value;
}

function parseSendResult(value) {
  if (!isRecord(value)) fail("send result", "对象");
  string("result.sessionId", value.sessionId);
  return value;
}

function parseCreateRequest(value) {
  if (!isRecord(value)) fail("create request", "对象");
  if (value.workspaceId !== undefined && value.workspaceId !== null) string("request.workspaceId", value.workspaceId);
  return value;
}

function parseCreateResult(value) {
  if (!isRecord(value)) fail("create result", "对象");
  string("result.sessionId", value.sessionId);
  return value;
}

const invocation = (method, parameters, parseResult) => ({
  id: `${PACKAGE}#sessionHandoff/${method}`,
  service: "sessionHandoff",
  namespace: "sessionHandoff",
  method,
  invocation: { kind: "direct" },
  parameters,
  result: result(`${method[0].toUpperCase()}${method.slice(1)}`, parseResult)
});

export const TYPERT = {
  package: PACKAGE,
  face: "host",
  schemas: [],
  invocations: [
    invocation("targets", [], parseTargetsResult),
    invocation("titles", [parameter("request", parseTitlesRequest)], parseTitlesResult),
    invocation("create", [parameter("request", parseCreateRequest)], parseCreateResult),
    invocation("send", [parameter("request", parseSendRequest)], parseSendResult)
  ],
  model: { services: [], events: [], objects: [] }
};
