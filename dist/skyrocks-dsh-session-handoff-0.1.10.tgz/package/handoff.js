// 交接编排：只依赖注入进来的服务对象，不依赖 Cordis 上下文，因此可以用假服务直接单测
// （见 test/handoff.test.mjs）。index.js 只负责把真实服务接进来。
//
// 一次交接 = 读源会话 → 切出「最近 N 轮 + 更早摘要」→ 拼一条消息 → 落到目标会话：
//   · 目标不存在就按选定的 workspace 新建；
//   · 目标已存在就直接投递（正忙则排队）。
import { writeFileSync } from "node:fs";

import { SUMMARY_SYSTEM_PROMPT, clamp, composeBundle, splitConversation } from "./context.js";

const DEFAULT_RECENT_TURNS = 3;
const DEFAULT_SUMMARY_MAX_CHARS = 1200;
const DEFAULT_SUMMARY_INPUT_CHARS = 8000;
const DEFAULT_VERBATIM_MAX_CHARS = 12000;
/** 只读尾部的多少条消息：够覆盖「最近几轮 + 一段更早的讨论」。 */
const DEFAULT_WINDOW_MESSAGES = 60;
/** 更早的原文短于这个长度就直接原样带上，不值得为它调一次模型。 */
const DEFAULT_SUMMARIZE_THRESHOLD = 1200;
/** 摘要不能拖住整次交接：超时就降级成原文。 */
const SUMMARY_TIMEOUT_MS = 12000;
const LOOSE_GROUP_ID = "";
/** 写进调试文件，用来确认跑的是哪一版 Host 代码。 */
const BUILD = "0.1.10";

/** 带稳定 code 的插件错误；Client 直接展示 message。 */
export function handoffError(code, message) {
  const error = new Error(message);
  error.code = code;
  return error;
}

export function requireString(value, field) {
  if (typeof value !== "string" || value.trim().length === 0) {
    throw handoffError("handoff/bad-request", `缺少 ${field}`);
  }
  return value.trim();
}

function requireService(services, name) {
  const service = services[name];
  if (service === undefined || service === null) {
    throw handoffError("handoff/unavailable", `当前组合缺少 ${name} 服务`);
  }
  return service;
}

/** 从 readTitleSnapshots 的结果里取出标题，兼容不同返回形态。 */
export function titleOf(result) {
  if (result === null || typeof result !== "object") return undefined;
  for (const candidate of [result, result.value, result.result]) {
    if (candidate === null || typeof candidate !== "object") continue;
    if (typeof candidate.title === "string" && candidate.title.trim().length > 0) return candidate.title.trim();
    if (typeof candidate.title?.title === "string" && candidate.title.title.trim().length > 0) {
      return candidate.title.title.trim();
    }
  }
  return undefined;
}

/** 会话摘要里的标题投影，作为 readTitleSnapshots 的兜底。 */
function projectedTitle(item) {
  const title = item?.projections?.values?.title;
  if (typeof title === "string" && title.trim().length > 0) return title.trim();
  if (typeof title?.title === "string" && title.title.trim().length > 0) return title.title.trim();
  return undefined;
}

function shortTitle(title, sessionId) {
  if (typeof title === "string" && title.trim().length > 0) return title.trim();
  const tail = typeof sessionId === "string" ? sessionId.slice(-6) : "??????";
  return `未命名会话 ${tail}`;
}

function limitOf(value, fallback) {
  return Number.isFinite(value) && value > 0 ? value : fallback;
}

/**
 * 列出全部工作区及其中的会话，供选择器分组展示。
 * 不含归档会话、空白占位会话和 subagent 子会话。
 * @param {object} services 已解析的服务集合
 * @returns {Promise<{ groups: Array<object> }>}
 */
export async function listTargets(services) {
  try {
    return await collectTargets(services);
  } catch (error) {
    const detail = { message: String(error?.message ?? error), stack: String(error?.stack ?? "") };
    services.logger?.warn?.(`session-handoff: 列出会话失败：${detail.message}`);
    writeDebug({ phase: "targets", error: detail });
    return { groups: [], stats: null, error: detail };
  }
}

function writeDebug(payload) {
  try {
    // 仅用于排查「列表为什么是空的」：写一个固定文件，不影响主流程。
    writeFileSync(
      "/tmp/dsh-session-handoff-debug.json",
      JSON.stringify({ at: new Date().toISOString(), build: BUILD, ...payload }, null, 2)
    );
  } catch {
    // 调试信息写不了就算了。
  }
}

async function collectTargets(services) {
  const controller = requireService(services, "sessionController");
  const registry = requireService(services, "workspaceRegistry");
  const query = services.sessionQuery;
  const signal = services.signal?.() ?? new AbortController().signal;

  // 主数据源是 session/list（带 running、blank、标题投影）。
  // 它按 remoteAccess 过滤；万一被过滤空（或只回来一部分），再用 sessionQuery 的
  // 逻辑语料补全——宁可多一次读，也不能让用户看到一个空列表。
  let listed;
  try {
    listed = await controller.list({}, signal);
  } catch (error) {
    services.logger?.warn?.(`session-handoff: session/list 失败，改用逻辑语料：${String(error)}`);
    listed = { items: [] };
  }
  const items = Array.isArray(listed?.items) ? listed.items : [];

  let records = [];
  try {
    if (query !== undefined && query !== null && typeof query.listSessions === "function") {
      records = await query.listSessions(signal);
    }
  } catch (error) {
    services.logger?.warn?.(`session-handoff: 读取会话语料失败：${String(error)}`);
    records = [];
  }
  const known = new Set(items.map((item) => item?.sessionId));
  for (const record of Array.isArray(records) ? records : []) {
    const header = record?.header ?? {};
    const sessionId = header.id;
    if (typeof sessionId !== "string" || sessionId.length === 0) continue;
    if (known.has(sessionId)) continue;
    // 没有 cwd 的记录不是可打开的会话目录，session/list 也是这样跳过的。
    if (typeof header.cwd !== "string" || header.cwd.length === 0) continue;
    known.add(sessionId);
    items.push({
      sessionId,
      updatedAt: Number.isFinite(header.createdAt) ? header.createdAt : 0,
      blank: false,
      ...(header.origin === undefined ? {} : { origin: header.origin }),
      ...(header.parentSession === undefined ? {} : { parentSessionId: header.parentSession }),
      cwd: header.cwd
    });
  }

  const workspaces = registry.list();
  const archived = new Set(registry.archivedSessionIds ?? []);

  const workspaceOf = new Map();
  for (const workspace of workspaces) {
    for (const sessionId of workspace.sessionIds ?? []) workspaceOf.set(sessionId, workspace.id);
  }

  const groups = new Map();
  const ensureGroup = (id, title, path) => {
    const existing = groups.get(id);
    if (existing !== undefined) return existing;
    const created = { id, title, path, sessions: [] };
    groups.set(id, created);
    return created;
  };

  for (const workspace of workspaces) ensureGroup(workspace.id, workspace.title, workspace.path);

  for (const item of items) {
    const sessionId = item?.sessionId;
    if (typeof sessionId !== "string" || sessionId.length === 0) continue;
    if (archived.has(sessionId)) continue;
    if (item.blank === true) continue;
    if (item.origin === "subagent" || typeof item.parentSessionId === "string") continue;
    const workspaceId = workspaceOf.get(sessionId);
    const group =
      workspaceId === undefined ? ensureGroup(LOOSE_GROUP_ID, "未归入工作区", "") : groups.get(workspaceId);
    if (group === undefined) continue;
    const projected = projectedTitle(item);
    group.sessions.push({
      sessionId,
      title: shortTitle(projected, sessionId),
      titleKnown: typeof projected === "string",
      updatedAt: Number.isFinite(item.updatedAt) ? item.updatedAt : 0,
      running: item.running === true
    });
  }

  const ordered = [];
  let total = 0;
  for (const group of groups.values()) {
    group.sessions.sort((left, right) => right.updatedAt - left.updatedAt);
    if (group.sessions.length === 0) continue;
    total += group.sessions.length;
    ordered.push(group);
  }
  ordered.sort((left, right) => (right.sessions[0]?.updatedAt ?? 0) - (left.sessions[0]?.updatedAt ?? 0));

  const skipped = { blank: 0, archived: 0, subagent: 0 };
  for (const item of items) {
    if (item?.blank === true) skipped.blank += 1;
    else if (archived.has(item?.sessionId)) skipped.archived += 1;
    else if (item?.origin === "subagent" || typeof item?.parentSessionId === "string") skipped.subagent += 1;
  }

  const result = {
    groups: ordered,
    stats: {
      listed: items.length,
      records: Array.isArray(records) ? records.length : 0,
      sessions: total,
      workspaces: ordered.length,
      skipped
    }
  };
  writeDebug({
    phase: "targets",
    listed: result.stats.listed,
    records: result.stats.records,
    sessions: result.stats.sessions,
    workspaces: result.stats.workspaces,
    skipped,
    sample: items.slice(0, 3).map((item) => ({
      sessionId: item?.sessionId,
      cwd: item?.cwd,
      blank: item?.blank,
      origin: item?.origin,
      parent: item?.parentSessionId
    }))
  });
  return result;
}

/**
 * 批量补标题：列表先出，标题后补。
 * 冷会话的标题不在列表投影里，需要逐个读日志折叠，所以单独一次调用、分批进行。
 * @param {object} services 已解析的服务集合
 * @param {string[]} sessionIds 需要补标题的会话
 * @returns {Promise<{ titles: Record<string, string> }>}
 */
export async function listTitles(services, sessionIds) {
  const query = requireService(services, "sessionQuery");
  const ids = Array.isArray(sessionIds)
    ? [...new Set(sessionIds.filter((id) => typeof id === "string" && id.length > 0))]
    : [];
  const titles = {};
  const signal = services.signal?.() ?? new AbortController().signal;
  for (let offset = 0; offset < ids.length; offset += 50) {
    const chunk = ids.slice(offset, offset + 50);
    try {
      const results = await query.readTitleSnapshots(chunk, signal);
      for (const result of Array.isArray(results) ? results : []) {
        const sessionId = result?.sessionId ?? result?.session?.id ?? result?.value?.session?.id;
        const title = titleOf(result);
        if (typeof sessionId === "string" && title !== undefined) titles[sessionId] = title;
      }
    } catch {
      // 某一批失败就跳过，前端保留兜底标题。
    }
  }
  return { titles };
}

/** 单个会话的最新标题；读不到就返回 undefined。 */
export async function readSessionTitle(services, sessionId) {
  try {
    const query = services.sessionQuery;
    if (query === undefined || query === null) return undefined;
    const results = await query.readTitleSnapshots([sessionId], services.signal?.() ?? new AbortController().signal);
    for (const result of Array.isArray(results) ? results : []) {
      const title = titleOf(result);
      if (title !== undefined) return title;
    }
  } catch {
    // 标题只是展示信息。
  }
  return undefined;
}

/**
 * 只读源会话的尾部窗口，避免重放整份日志。
 *
 * `sessionQuery.readSession` 会读入并重放校验**完整**日志，长会话上这一步会占住
 * Host 的事件循环好几秒，整个 Web 界面跟着卡住。`sessionController.events` 按消息
 * 分页，活动的会话直接取内存投影，代价只和窗口大小有关。
 * @param {object} services 已解析的服务集合
 * @param {string} sessionId 源会话
 * @param {number} maxMessages 最多取多少条消息
 * @returns {Promise<{ events: object[], hasMore: boolean, source: string }>}
 */
async function readTail(services, sessionId, maxMessages) {
  const controller = services.sessionController;
  if (controller !== undefined && controller !== null && typeof controller.events === "function") {
    try {
      const page = await controller.events(
        { address: { kind: "session", sessionId }, maxMessages },
        services.signal?.() ?? new AbortController().signal
      );
      const records = Array.isArray(page?.records) ? page.records : [];
      const events = records.map((record) => record?.event ?? record).filter((event) => event !== null && event !== undefined);
      if (events.length > 0) return { events, hasMore: page?.hasMore === true, source: "page" };
    } catch (error) {
      services.logger?.warn?.(`session-handoff: 分页读历史失败，退回完整日志：${String(error)}`);
    }
  }
  const log = await requireService(services, "sessionQuery").readSession(sessionId);
  const all = Array.isArray(log?.events) ? log.events : [];
  const tail = maxMessages > 0 ? all.slice(-maxMessages) : all;
  return { events: tail, hasMore: tail.length < all.length, source: "log" };
}

/**
 * 源会话的标题与 cwd：只折一次标题、拿一次 header，不读整份日志。
 * @returns {Promise<{ title?: string, cwd?: string }>}
 */
async function readSourceMeta(services, sessionId) {
  const query = services.sessionQuery;
  if (query !== undefined && query !== null && typeof query.readTitleSnapshot === "function") {
    try {
      const observation = await query.readTitleSnapshot(sessionId, services.signal?.() ?? new AbortController().signal);
      return {
        title: titleOf(observation),
        cwd: typeof observation?.session?.cwd === "string" ? observation.session.cwd : undefined
      };
    } catch {
      // 拿不到就退回单独折标题。
    }
  }
  return { title: await readSessionTitle(services, sessionId), cwd: undefined };
}

/** 源会话正在用的模型；拿不到就退回部署默认模型。 */
export function modelFor(services, sourceSessionId) {
  const current = services.agents?.get?.(sourceSessionId)?.model?.current?.();
  if (current !== undefined && typeof current.provider === "string" && typeof current.model === "string") {
    return current;
  }
  const fallback = services.agentDefaultModel?.currentSelection?.();
  if (fallback !== undefined && typeof fallback.provider === "string" && typeof fallback.model === "string") {
    return fallback;
  }
  return undefined;
}

/**
 * 用当前可用模型把更早的讨论压成一段摘要。
 * 摘要失败不抛错：降级成截断的原文，交接照常进行。
 */
export async function summarize(services, config, text, sourceSessionId) {
  const llm = services.llm;
  if (llm === undefined || llm === null) return "";
  const selection = modelFor(services, sourceSessionId);
  const maxChars = limitOf(config.summaryMaxChars, DEFAULT_SUMMARY_MAX_CHARS);
  if (selection === undefined) {
    services.logger?.warn?.("session-handoff: 没有可用模型，本次只发送最近几轮原文");
    return "";
  }
  const input = clamp(text, limitOf(config.summaryInputChars, DEFAULT_SUMMARY_INPUT_CHARS));
  const chunks = [];
  const timeout =
    typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function"
      ? AbortSignal.timeout(SUMMARY_TIMEOUT_MS)
      : undefined;
  const caller = services.signal?.();
  const signal =
    timeout !== undefined && caller !== undefined && typeof AbortSignal.any === "function"
      ? AbortSignal.any([timeout, caller])
      : (timeout ?? caller);
  try {
    const stream = llm.stream({
      provider: selection.provider,
      model: selection.model,
      ...(selection.reasoningEffort === undefined ? {} : { reasoningEffort: selection.reasoningEffort }),
      system: SUMMARY_SYSTEM_PROMPT,
      // 摘要只要要点：低温、限长，避免为了几百字等十几秒。
      temperature: 0,
      maxTokens: 480,
      ...(signal === undefined ? {} : { signal }),
      messages: [{ role: "user", content: [{ type: "text", text: input }] }]
    });
    for await (const chunk of stream) {
      if (chunk?.type === "text-delta" && typeof chunk.text === "string") chunks.push(chunk.text);
    }
  } catch (error) {
    services.logger?.warn?.(`session-handoff: 摘要失败，降级为原文：${String(error)}`);
    return "";
  }
  const summary = chunks.join("").trim();
  return summary.length === 0 ? "" : clamp(summary, maxChars);
}

/**
 * 先建一个空会话（不投递内容）。
 *
 * 客户端需要它：新建的空会话在客户端是「当前空白会话」，DSH 侧栏的手动排序会
 * 据此把它提到工作区最前；Host 侧建完就发的话，顺序表里没有它，只能排到最后。
 */
export async function createTarget(services, request) {
  const controller = requireService(services, "sessionController");
  const workspaceId =
    typeof request?.workspaceId === "string" && request.workspaceId.trim().length > 0
      ? request.workspaceId.trim()
      : undefined;
  const created = await controller.create(workspaceId === undefined ? {} : { workspaceId });
  return { sessionId: created.sessionId };
}

/**
 * 把源会话的一段上下文投递到目标会话（不存在则新建），并让它接着跑。
 * @param {object} services 已解析的服务集合
 * @param {object} config 插件配置
 * @param {{ sourceSessionId: string, messageId?: string,
 *           target?: { kind: 'new', workspaceId?: string } | { kind: 'existing', sessionId: string } }} request
 */
export async function sendHandoff(services, config, request) {
  const sourceSessionId = requireString(request?.sourceSessionId, "sourceSessionId");
  const target = request?.target ?? { kind: "new" };
  const kind = target.kind === "existing" ? "existing" : "new";
  // kind === "new" 时也可以带 sessionId：客户端先把空会话建好、切过去，
  // 侧栏的手动顺序会据此把它提到最前，Host 再往这个会话里投递。
  const presetTargetId =
    kind === "new" && typeof target.sessionId === "string" && target.sessionId.trim().length > 0
      ? target.sessionId.trim()
      : null;
  const targetSessionId =
    kind === "existing" ? requireString(target.sessionId, "target.sessionId") : presetTargetId;
  if (targetSessionId !== null && targetSessionId === sourceSessionId) {
    throw handoffError("handoff/same-session", "不能把讨论发回它自己所在的会话");
  }

  const controller = requireService(services, "sessionController");
  const started = Date.now();
  const timings = {};
  const mark = (name, from) => {
    timings[name] = Date.now() - from;
  };

  const metaStarted = Date.now();
  const metaPromise = readSourceMeta(services, sourceSessionId);
  const windowStarted = Date.now();
  const tail = await readTail(services, sourceSessionId, limitOf(config.windowMessages, DEFAULT_WINDOW_MESSAGES));
  mark("window", windowStarted);
  const events = tail.events;
  if (events.length === 0) throw handoffError("handoff/empty-session", "这个会话还没有可交接的内容");

  const split = splitConversation(events, {
    messageId: typeof request?.messageId === "string" ? request.messageId : undefined,
    recentTurns: limitOf(config.recentTurns, DEFAULT_RECENT_TURNS),
    verbatimMaxChars: limitOf(config.verbatimMaxChars, DEFAULT_VERBATIM_MAX_CHARS)
  });
  if (split.recentText.length === 0 && split.historyText.length === 0) {
    throw handoffError("handoff/empty-context", "这个会话里没有可交接的对话内容");
  }

  const meta = await metaPromise;
  mark("meta", metaStarted);
  const sourceTitle = meta.title;

  // 新建会话可以和摘要并行：建会话不依赖正文。
  const createStarted = Date.now();
  const creating =
    kind === "new" && targetSessionId === null
      ? Promise.resolve().then(() =>
          (typeof target.workspaceId === "string" && target.workspaceId.trim().length > 0
            ? controller.create({ workspaceId: target.workspaceId.trim() })
            : controller.create(meta.cwd === undefined ? {} : { cwd: meta.cwd })
          ).then(
            (created) => ({ sessionId: created.sessionId }),
            (error) => ({ error })
          )
        )
      : Promise.resolve(null);

  // 更早的讨论够长才值得调模型；短则原样带上，点击即发。
  const threshold = limitOf(config.summarizeThreshold, DEFAULT_SUMMARIZE_THRESHOLD);
  const needsModel = split.historyText.trim().length > threshold;
  let summary = "";
  let summaryMode = "none";
  if (split.historyText.length > 0) {
    const summaryStarted = Date.now();
    if (needsModel) {
      summary = await summarize(services, config, split.historyText, sourceSessionId);
      summaryMode = summary.length > 0 ? "model" : "none";
      if (summary.length === 0) {
        summary = clamp(split.historyText.trim(), limitOf(config.summaryMaxChars, DEFAULT_SUMMARY_MAX_CHARS));
        summaryMode = "verbatim";
      }
    } else {
      summary = clamp(split.historyText.trim(), limitOf(config.summaryMaxChars, DEFAULT_SUMMARY_MAX_CHARS));
      summaryMode = "verbatim";
    }
    mark("summary", summaryStarted);
  }
  const body = composeBundle({
    sourceTitle,
    summary,
    recentText: split.recentText,
    summaryIsRaw: summaryMode === "verbatim",
    truncated: tail.hasMore
  });

  let sessionId = targetSessionId;
  if (sessionId === null) {
    const creation = await creating;
    if (creation?.error !== undefined) throw creation.error;
    sessionId = creation.sessionId;
    mark("create", createStarted);
  }
  if (kind === "new" && config.nameNewSessions !== false) {
    const renameStarted = Date.now();
    await nameSession(services, sessionId, sourceTitle);
    mark("rename", renameStarted);
  }

  const promptStarted = Date.now();
  await controller.prompt(
    {
      sessionId,
      requestId: `handoff-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
      mode: "queue",
      content: [{ type: "text", text: body }]
    },
    services.signal?.() ?? new AbortController().signal
  );
  mark("prompt", promptStarted);
  timings.total = Date.now() - started;
  writeDebug({ phase: "send", source: tail.source, hasMore: tail.hasMore, timings, chars: body.length });

  return {
    sessionId,
    created: targetSessionId === null,
    summarized: summaryMode === "model",
    summaryMode,
    turns: split.recentTurns,
    chars: body.length,
    timings
  };
}

/** 新会话命名失败不影响交接。 */
async function nameSession(services, sessionId, sourceTitle) {
  try {
    const suffix = typeof sourceTitle === "string" && sourceTitle.trim().length > 0 ? sourceTitle.trim() : "另一个会话";
    const title = `来自：${suffix}`.slice(0, 60);
    await services.sessionController.rename({ sessionId, title });
  } catch (error) {
    services.logger?.warn?.(`session-handoff: 新会话命名失败：${String(error)}`);
  }
}
