# Changelog

## 0.1.10 — 2026-11-27

首个公开发布版本，随仓库与 dsh-plugins 索引一起发布。0.1.0–0.1.9 为发布前的内部迭代。

功能要点：

- 助手回复的工具条新增「发送到会话」，把最近 3 轮原文 + 更早内容的摘要投递到任意工作区的会话。
- 目标会话先复述任务再等你确认；新会话按「来自：<源会话标题>」命名。
- 摘要失败降级为只发原文；没有可用模型时跳过摘要。
- 弹层底部显示客户端版本号；Host 返回结构异常时把原始内容显示出来，不再只剩空列表。

## 0.1.7

- **根因修复**：typert 的客户端调用返回信封 `{ ok, value }`，真实数据在 `value` 里。之前直接读 `result.groups`，所以 `targets` 永远是空、`send` 也拿不到 sessionId。现在统一经 `call()` 解包并处理 `ok:false`。
- 新增回归测试：伪造 `{ok:true,value:{groups:[...]}}`，断言弹层真的把这些会话渲染出来。

## 0.1.6

- 弹层底部显示客户端版本号（`v0.1.6`），用来判断浏览器跑的是不是最新 bundle。
- 主机返回的结构不认识时，把原始内容截断后显示在界面上，不再只剩「没有可选的会话」。

## 0.1.5

- 客户端区分「空列表」和「主机返回 undefined」，后者直接提示 Host 可能是旧版本。
- Host 每次列会话都会把版本号和统计写到 `/tmp/dsh-session-handoff-debug.json`，用来确认运行时到底跑的哪一版代码。
- `targets()` 异常不再静默：错误回到界面，同时写进调试文件。

## 0.1.4

- **根因修复**：Host 清单里的结果 typeSymbol 少了 `SessionHandoff` 前缀（`#TargetsResult` vs 客户端声明的 `#SessionHandoffTargetsResult`），strict codec 校验对不上，客户端拿到的永远是 `undefined` —— 表现就是弹层「没有可选的会话」，且诊断行也不出现。`targets` / `titles` / `send` 三个调用此前全部受影响。
- 新增契约测试：Host 清单与 Client 描述符逐字段比对（id / service / namespace / method / 参数与结果 typeSymbol），这类错以后会被测试直接挡住。

## 0.1.3

- 修复弹层显示原始 key（dialogTitle / search / noTargets）：把 `locale` 声明为依赖，并给 `tr()` 加内置词典兜底，宿主 locale 缺失或缺 key 时也不会把 key 直接显示出来。
- 修复列表为空：`session/list` 会按 `remoteAccess` 过滤，插件侧调用可能被滤空；现在用 `sessionQuery.listSessions()` 的逻辑语料补齐，两边任一有数据都能列出来。
- 空列表时显示诊断行（主机返回多少条、语料多少条、各跳过了多少），下次再出问题能直接定位。

## 0.1.2

- 交接包末尾改成「先复述理解、不要动手、等我进一步指示」，目标会话第一轮只输出理解，不改任何东西。
- 修复选择器长时间列不出会话：列表不再为了标题逐个读日志，改为先出列表、标题异步补齐（`sessionHandoff/titles`）。
- 修复发送后没有跳到目标会话：等客户端会话列表认识新 id 后再 `openSession`，切换失败时在提示里说明。
- 工具条图标补上 hover / active / 键盘焦点反馈。
- 选择器底部显示「共 N 个会话 · M 个工作区」，便于确认有没有漏列。

## 0.1.1

- Host 半改为只依赖公开服务：`sessionController`（建会话 / 投递 / 命名）、`sessionQuery`（读日志与标题）、
  `workspaceRegistry`（工作区分组）、`llm` + `agentDefaultModel`（摘要）。
- 轮次按 `turn/start` 切分，点最后一条回复时不会漏掉当前这轮；旧日志退回 `turn/end`。
- 摘要失败或无可用模型时降级为只发最近几轮原文。

## 0.1.0

- 首个版本：助手回复工具条上的「发送到会话」，按工作区分组选择目标，自动打包「最近 3 轮 + 更早摘要」并投递。
