# @skyrocks/dsh-session-handoff

Carry the discussion you are having in one session into another one, in DeepSeek Harness (`dsh`).

DSH can continue inside a session, or export the whole log to a file. Moving a discussion somewhere
else — a clean session, another project, another workspace — means copy, paste, and deciding by hand
how much to keep. This plugin makes it one click: **Send to session** under any assistant reply.

## What it carries

You do not pick a range; the plugin decides:

1. The **last 3 turns verbatim** (what the user asked and what the assistant answered).
2. Everything earlier, compressed into a **summary** (one model call, using the session's current model).
3. One closing instruction so the target session knows to continue.

Only **human conversation** travels: synthetic `agent.inject` context, tool calls, and tool results are
left behind. The target gets a discussion, not a log.

## How to use it

1. On any assistant reply, click the **Send to session** icon at the right end of the action row.
2. The picker shows **New session** (with a workspace selector) and every session grouped **by workspace**.
3. Click one. The plugin sends, then opens the target session — which does **not** start working: it restates the task for you to confirm first.

## Behaviour

| Case | Result |
| --- | --- |
| First reaction in the target | Restates what to do, the scope and constraints, what is done, and how it plans to start — then waits for you |
| Existing target | One message is delivered; a busy session queues it after its current turn |
| New target | Created in the chosen workspace and named `From: <source title>` |
| Nothing to carry | Refused with an explanation — no empty message is sent |
| Summary fails | Falls back to the recent turns only |
| No model available | Skips the summary, sends the recent turns |

## Costs and limits

- The summary costs **one model call** (source session's model, else the deployment default).
- **Cross-workspace means cross-project**: the text is persisted in the target session's log.
- The target session **runs one turn** — that turn only restates the task and changes nothing.
- Reading history and summarizing happen on the Host, so the Host half must be loaded.

## Install

```sh
dsh plugin --profile desktop add "link:/Users/shilei/PrivateCode/dsh/dsh-session-handoff"
```

Restart DSH completely afterwards; Host plugins load at startup. `dsh web` users replace
`--profile desktop` with `--profile web`.

## Configuration

```yaml
- id: session-handoff
  config:
    recentTurns: 3
    summaryMaxChars: 1200
    summaryInputChars: 24000
    verbatimMaxChars: 12000
    nameNewSessions: true
```

## Requirements

- DSH `>=0.2.2-rc.5 <0.3.0` — the Host half uses internal services (`sessionController`, `workspaceRegistry`, `llm`), so a mismatch fails to load.
- Node.js `>=18`. The plugin has no runtime dependencies.
- The summary needs a model: the session's current model when available, otherwise the deployment default.

## FAQ

**The picker is empty.** Make sure the Host half is installed — it ships in the same package. The picker shows the client bundle version at the bottom; if it is missing or the UI says the Host may be outdated, fully quit DSH (⌘Q) and reopen.

**Can it cross workspaces?** Yes — the picker lists every workspace's sessions, grouped by workspace, and New session lets you pick the target workspace. Cross-workspace means cross-project: the text is persisted in the target log.

**Will the target start editing right away?** No. It restates the task, scope, what is done, and how it plans to start, then waits for you.

**Why only the last 3 turns?** Earlier content is already compressed into a summary, and tool calls/results are dropped on purpose. Change the defaults in the profile's `cordis.patch.yml` (see Configuration).

**Can I take it back?** No. The message is in the target session's log; ask that session to drop the task instead.

**Nothing happens after install.** Host plugins load at startup — fully quit and reopen DSH, a page refresh is not enough.

## License

MIT
