// Client 半：助手回复下方的「发送到会话」按钮 + 目标选择器 + 结果提示。
//
// 手写 lazy-CJS bundle：脚本执行时只注册 factory，模块体在 materialize 时才运行。
// 只依赖 React 与 DSH 既有服务（slots / remote / locale / uiWorkspace），不引入 primitives，
// 避免跨包版本耦合。
window.__ModuleLoader__.load({
  id: "@skyrocks/dsh-session-handoff",
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
    const React = require("react");
    const h = React.createElement;

    const NS = "session-handoff";
    const BUILD = "0.1.10";
    const PACKAGE = "@skyrocks/dsh-session-handoff";
    const PER_GROUP_LIMIT = 60;

    // Client 只声明调用形状；真正的校验在 Host 侧完成，这里直通。
    const passThrough = () => ({ parse: (value) => value });
    const codec = (typeSymbol) => ({ mode: "strict", typeSymbol, create: passThrough });
    const parameter = (name) => ({
      name,
      wire: name,
      source: "json",
      codec: codec(`${PACKAGE}#${name}`)
    });

    const REMOTE = {
      package: PACKAGE,
      descriptors: [
        {
          id: `${PACKAGE}#sessionHandoff/targets`,
          service: "sessionHandoff",
          namespace: "sessionHandoff",
          method: "targets",
          invocation: { kind: "direct" },
          parameters: [],
          result: codec(`${PACKAGE}#SessionHandoffTargetsResult`)
        },
        {
          id: `${PACKAGE}#sessionHandoff/titles`,
          service: "sessionHandoff",
          namespace: "sessionHandoff",
          method: "titles",
          invocation: { kind: "direct" },
          parameters: [parameter("request")],
          result: codec(`${PACKAGE}#SessionHandoffTitlesResult`)
        },
        {
          id: `${PACKAGE}#sessionHandoff/create`,
          service: "sessionHandoff",
          namespace: "sessionHandoff",
          method: "create",
          invocation: { kind: "direct" },
          parameters: [parameter("request")],
          result: codec(`${PACKAGE}#SessionHandoffCreateResult`)
        },
        {
          id: `${PACKAGE}#sessionHandoff/send`,
          service: "sessionHandoff",
          namespace: "sessionHandoff",
          method: "send",
          invocation: { kind: "direct" },
          parameters: [parameter("request")],
          result: codec(`${PACKAGE}#SessionHandoffSendResult`)
        }
      ]
    };

    const DICT = {
      zh: {
        action: "发送到会话",
        actionTitle: "把这段讨论带到另一个会话继续",
        dialogTitle: "发送到会话",
        close: "关闭",
        search: "搜索会话…",
        newSession: "新会话",
        newSessionIn: "在此新建会话",
        hint: "自动带上最近 3 轮原文，更早的内容压缩成摘要。",
        loading: "正在读取会话…",
        stats: "共 {sessions} 个会话 · {workspaces} 个工作区",
        openManually: "可在侧栏打开",
        expand: "展开",
        collapse: "收起",
        moreSessions: "还有 {n} 个，用上方搜索缩小范围",
        running: "运行中",
        sending: "发送中…",
        preparing: "正在整理上下文并发送…",
        preparingHint: "首次发送要把更早的讨论压成摘要，通常几秒；目标会话正忙时会排队。",
        elapsed: "已 {n} 秒",
        empty: "没有匹配的会话",
        noTargets: "没有可选的会话",
        diag: "主机返回 {listed} 条记录（语料 {records} 条），已跳过 {blank} 个空会话、{archived} 个归档、{subagent} 个子会话",
        emptyResponse: "主机返回了空响应（undefined）：Host 插件可能没有加载到最新版本，重启 DSH 再试",
        unexpected: "主机返回了无法识别的结果",
        sentTo: "已发送到「{title}」",
        sentQueued: "已发送到「{title}」，排队等它这轮跑完",
        sentNew: "已在新会话里开始",
        open: "打开会话",
        dismiss: "知道了",
        failed: "发送失败",
        unavailable: "会话交接服务不可用（Host 未加载）",
        justNow: "刚刚",
        minutes: "{n} 分钟前",
        hours: "{n} 小时前",
        days: "{n} 天前"
      },
      en: {
        action: "Send to session",
        actionTitle: "Carry this discussion into another session",
        dialogTitle: "Send to session",
        close: "Close",
        search: "Search sessions…",
        newSession: "New session",
        newSessionIn: "New session here",
        hint: "Sends the last 3 turns verbatim and a summary of everything earlier.",
        loading: "Loading sessions…",
        stats: "{sessions} sessions · {workspaces} workspaces",
        openManually: "open it from the sidebar",
        expand: "Expand",
        collapse: "Collapse",
        moreSessions: "{n} more — narrow it down with the search above",
        running: "Running",
        sending: "Sending…",
        preparing: "Preparing context and sending…",
        preparingHint: "The first send summarizes the earlier discussion, which takes a few seconds; a busy target queues it.",
        elapsed: "{n}s",
        empty: "No matching session",
        noTargets: "No target session yet",
        diag: "Host returned {listed} records (corpus {records}); skipped {blank} blank, {archived} archived, {subagent} subagent",
        emptyResponse: "The Host returned no value (undefined): the Host plugin may not be the latest build — restart DSH",
        unexpected: "The Host returned an unrecognized result",
        sentTo: "Sent to \"{title}\"",
        sentQueued: "Sent to \"{title}\"; it will run after the current turn",
        sentNew: "Started a new session",
        open: "Open session",
        dismiss: "Dismiss",
        failed: "Send failed",
        unavailable: "Session handoff is unavailable (Host not loaded)",
        justNow: "just now",
        minutes: "{n} min ago",
        hours: "{n} h ago",
        days: "{n} d ago"
      }
    };

    /** 极小的可订阅快照，够本插件用，不引第三方状态库。 */
    function createStore(initial) {
      const listeners = new Set();
      let value = initial;
      return {
        get: () => value,
        set(next) {
          value = next;
          for (const listener of listeners) listener();
        },
        subscribe(listener) {
          listeners.add(listener);
          return () => {
            listeners.delete(listener);
          };
        }
      };
    }

    const emptyDialog = {
      open: false,
      sessionId: "",
      messageId: "",
      loading: false,
      sending: false,
      sendingSince: 0,
      error: null,
      groups: null,
      stats: null,
      collapsed: {},
      query: ""
    };

    const dialogState = createStore(emptyDialog);
    const toastState = createStore(null);

    let ctxRef = null;
    let mountReady = null;
    let tRef = null;
    let toastTimer = 0;

    /** 没有 locale 服务时的兜底词典，按浏览器语言选。 */
    function localDict() {
      const language =
        typeof navigator !== "undefined" && typeof navigator.language === "string"
          ? navigator.language.toLowerCase()
          : "en";
      return language.startsWith("zh") ? DICT.zh : DICT.en;
    }

    function interpolate(template, params) {
      if (params === null || params === undefined) return template;
      return template.replace(/\{(\w+)\}/g, (match, name) => (name in params ? String(params[name]) : match));
    }

    /** 优先用宿主 locale；拿不到或没有这个 key 就落到内置词典。 */
    function tr(key, params) {
      const translate = tRef;
      if (translate !== undefined && translate !== null) {
        const text = translate(key, params);
        if (typeof text === "string" && text !== key) return text;
      }
      const dictionary = localDict();
      const template = typeof dictionary[key] === "string" ? dictionary[key] : key;
      return interpolate(template, params);
    }

    function showToast(payload, timeoutMs) {
      toastState.set(payload);
      if (toastTimer !== 0) window.clearTimeout(toastTimer);
      toastTimer = window.setTimeout(() => {
        toastTimer = 0;
        toastState.set(null);
      }, typeof timeoutMs === "number" ? timeoutMs : 8000);
    }

    /** 客户端会话列表里是否有这个 id；没有就等它出现（新会话要等列表事件回来）。 */
    function whenListed(sessionId, timeoutMs) {
      const sessions = ctxRef === null ? undefined : ctxRef.get("sessions");
      const listed = () => {
        const snapshot = sessions?.list?.getSnapshot?.();
        return Boolean(snapshot && snapshot.byId && snapshot.byId[sessionId] !== undefined);
      };
      if (sessions === undefined || sessions === null || typeof sessions.list?.subscribe !== "function") {
        return Promise.resolve(false);
      }
      if (listed()) return Promise.resolve(true);
      return new Promise((resolve) => {
        let settled = false;
        let unsubscribe = () => {};
        const finish = (value) => {
          if (settled) return;
          settled = true;
          unsubscribe();
          resolve(value);
        };
        unsubscribe = sessions.list.subscribe(() => {
          if (listed()) finish(true);
        });
        window.setTimeout(() => finish(listed()), typeof timeoutMs === "number" ? timeoutMs : 2500);
      });
    }

    /** 把焦点切到目标会话；返回是否真的切过去了。 */
    async function focusSession(sessionId) {
      if (typeof sessionId !== "string" || sessionId.length === 0) return false;
      const workspace = ctxRef === null ? undefined : ctxRef.get("uiWorkspace");
      if (workspace === undefined || workspace === null || typeof workspace.openSession !== "function") return false;
      await whenListed(sessionId, 2500);
      try {
        workspace.openSession(sessionId);
        return true;
      } catch (error) {
        console.warn("session-handoff: 打开会话失败", error);
        return false;
      }
    }

    /** 把刚建好的空会话切成当前会话；它还是空白时，侧栏会把它提到工作区最前。 */
    async function openFresh(sessionId) {
      const workspace = ctxRef === null ? undefined : ctxRef.get("uiWorkspace");
      if (workspace === undefined || workspace === null || typeof workspace.openSession !== "function") return false;
      await whenListed(sessionId, 1500);
      try {
        workspace.openSession(sessionId);
      } catch (error) {
        console.warn("session-handoff: 打开新会话失败", error);
        return false;
      }
      // 等侧栏那一轮 ~pin+sync 渲染落地，再往里发内容。
      await new Promise((resolve) => window.setTimeout(resolve, 250));
      return true;
    }

    /**
     * 调一次 Host 方法。
     * typert 的返回值是信封 `{ ok, value }`：ok 为 false 时带 error，成功时数据在 value 里。
     */
    async function call(method, argument) {
      if (mountReady !== null && mountReady !== undefined) {
        try {
          await mountReady;
        } catch {
          // 挂载失败时下面取服务会报出来。
        }
      }
      const service = ctxRef === null ? undefined : ctxRef.get("remote.sessionHandoff");
      if (service === undefined || service === null) throw new Error(tr("unavailable"));
      const result = argument === undefined ? await service[method]() : await service[method](argument);
      if (!result || result.ok === false) {
        const reason = result && result.error ? result.error.message || String(result.error) : tr("failed");
        throw new Error(reason);
      }
      return result.value;
    }

    function relativeTime(timestamp) {
      if (typeof timestamp !== "number" || !Number.isFinite(timestamp) || timestamp <= 0) return "";
      const diff = Date.now() - timestamp;
      const minutes = Math.round(diff / 60000);
      if (minutes <= 1) return tr("justNow");
      if (minutes < 60) return tr("minutes", { n: minutes });
      const hours = Math.round(minutes / 60);
      if (hours < 24) return tr("hours", { n: hours });
      return tr("days", { n: Math.round(hours / 24) });
    }

    function useStore(store) {
      const [value, setValue] = React.useState(store.get);
      React.useEffect(() => store.subscribe(() => setValue(store.get())), [store]);
      return value;
    }

    const CSS = [
      ".dsh-sh-action{display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;border:0;border-radius:7px;background:transparent;color:inherit;cursor:pointer;opacity:.72;transition:background-color .12s ease,opacity .12s ease;}",
      ".dsh-sh-action:hover:not(:disabled){opacity:1;background:color-mix(in srgb,currentColor 12%,transparent);}",
      ".dsh-sh-action:active:not(:disabled){background:color-mix(in srgb,currentColor 20%,transparent);}",
      ".dsh-sh-action:focus-visible{opacity:1;outline:2px solid var(--dsw-alias-state-business-primary,#4d6bfe);outline-offset:1px;}",
      ".dsh-sh-action:disabled{opacity:.4;cursor:default;}",
      ".dsh-sh-backdrop{position:fixed;inset:0;z-index:2300;display:flex;align-items:flex-start;justify-content:center;padding:max(64px,9vh) 24px 24px;background:rgba(0,0,0,.38);}",
      ".dsh-sh-dialog{width:min(600px,100%);max-height:min(640px,76vh);display:flex;flex-direction:column;border-radius:14px;background:var(--dsw-alias-bg-module-platform,#fff);border:1px solid var(--dsw-alias-border-l1,rgba(127,127,127,.22));box-shadow:0 24px 64px rgba(0,0,0,.3);color:var(--dsw-alias-label-primary,#1f2329);overflow:hidden;}",
      ".dsh-sh-head{display:flex;align-items:center;justify-content:space-between;padding:18px 20px 12px;}",
      ".dsh-sh-head h2{margin:0;font-size:15px;font-weight:600;}",
      ".dsh-sh-close{display:flex;align-items:center;justify-content:center;width:28px;height:28px;border:0;border-radius:8px;background:transparent;color:var(--dsw-alias-label-secondary,#6b7280);cursor:pointer;font-size:16px;line-height:1;}",
      ".dsh-sh-close:hover{background:color-mix(in srgb,currentColor 10%,transparent);}",
      ".dsh-sh-searchwrap{position:relative;margin:0 20px 12px;}",
      ".dsh-sh-searchicon{position:absolute;left:11px;top:50%;transform:translateY(-50%);opacity:.45;pointer-events:none;display:flex;}",
      ".dsh-sh-search{width:100%;height:36px;padding:0 12px 0 34px;box-sizing:border-box;border-radius:10px;border:1px solid var(--dsw-alias-border-l2,rgba(127,127,127,.3));background:var(--dsw-alias-bg-elevated,rgba(127,127,127,.06));color:inherit;font-size:13px;outline:none;transition:border-color .12s ease,box-shadow .12s ease;}",
      ".dsh-sh-search::placeholder{color:var(--dsw-alias-label-tertiary,#8a8f98);}",
      ".dsh-sh-search:focus{border-color:var(--dsw-alias-state-business-primary,#4d6bfe);box-shadow:0 0 0 3px color-mix(in srgb,var(--dsw-alias-state-business-primary,#4d6bfe) 16%,transparent);}",
      ".dsh-sh-list{flex:1;min-height:0;overflow:auto;padding:0 10px 8px;}",
      ".dsh-sh-group{margin:0 2px 2px;}",
      ".dsh-sh-grouphead{display:flex;align-items:center;gap:8px;width:100%;padding:7px 10px;border:0;border-radius:8px;background:transparent;color:inherit;cursor:pointer;text-align:left;}",
      ".dsh-sh-grouphead:hover{background:color-mix(in srgb,currentColor 7%,transparent);}",
      ".dsh-sh-chev{flex:none;display:flex;opacity:.55;transition:transform .14s ease;}",
      ".dsh-sh-chev.open{transform:rotate(90deg);}",
      ".dsh-sh-gname{flex:none;max-width:46%;font-size:12.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}",
      ".dsh-sh-gpath{flex:1;min-width:0;font-size:11px;color:var(--dsw-alias-label-tertiary,#8a8f98);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;direction:rtl;text-align:left;}",
      ".dsh-sh-gcount{flex:none;padding:1px 7px;border-radius:999px;font-size:10.5px;color:var(--dsw-alias-label-tertiary,#8a8f98);background:color-mix(in srgb,currentColor 8%,transparent);}",
      ".dsh-sh-rows{padding:2px 0 8px;}",
      ".dsh-sh-newrow{display:flex;align-items:center;gap:8px;width:calc(100% - 20px);margin:2px 10px 6px;padding:7px 12px;border:1px dashed color-mix(in srgb,currentColor 22%,transparent);border-radius:8px;background:transparent;color:var(--dsw-alias-state-business-primary,#4d6bfe);font-size:12.5px;cursor:pointer;text-align:left;}",
      ".dsh-sh-newrow:hover:not(:disabled){border-style:solid;background:color-mix(in srgb,var(--dsw-alias-state-business-primary,#4d6bfe) 8%,transparent);}",
      ".dsh-sh-newrow:disabled{opacity:.5;cursor:default;}",
      ".dsh-sh-row{display:flex;align-items:center;gap:10px;width:100%;padding:8px 12px 8px 26px;border:0;border-radius:8px;background:transparent;color:inherit;text-align:left;cursor:pointer;font-size:12.5px;}",
      ".dsh-sh-row:hover:not(:disabled){background:color-mix(in srgb,currentColor 7%,transparent);}",
      ".dsh-sh-row:disabled{opacity:.55;cursor:default;}",
      ".dsh-sh-row-main{flex:1;min-width:0;}",
      ".dsh-sh-row-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}",
      ".dsh-sh-row-meta{margin-top:2px;font-size:10.5px;color:var(--dsw-alias-label-tertiary,#8a8f98);display:flex;gap:8px;}",
      ".dsh-sh-dot{color:var(--dsw-alias-state-success-primary,#2ea043);}",
      ".dsh-sh-more{padding:4px 12px 6px 26px;font-size:10.5px;color:var(--dsw-alias-label-tertiary,#8a8f98);}",
      ".dsh-sh-foot{display:flex;align-items:center;gap:10px;padding:10px 20px 12px;border-top:1px solid var(--dsw-alias-border-l1,rgba(127,127,127,.16));font-size:10.5px;color:var(--dsw-alias-label-tertiary,#8a8f98);}",
      ".dsh-sh-foot-hint{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}",
      ".dsh-sh-foot-stats{flex:none;}",
      ".dsh-sh-foot-build{flex:none;opacity:.55;}",
      ".dsh-sh-error{margin:0 20px 10px;padding:8px 11px;border-radius:8px;font-size:11.5px;color:var(--dsw-alias-state-error-primary,#e5484d);background:color-mix(in srgb,var(--dsw-alias-state-error-primary,#e5484d) 10%,transparent);word-break:break-word;}",
      ".dsh-sh-empty{padding:26px 12px;text-align:center;font-size:12px;color:var(--dsw-alias-label-tertiary,#8a8f98);}",
      "@keyframes dsh-sh-spin{to{transform:rotate(360deg);}}",
      ".dsh-sh-progress{display:flex;flex-direction:column;align-items:center;gap:10px;padding:46px 24px 40px;text-align:center;}",
      ".dsh-sh-spinner{width:22px;height:22px;border-radius:50%;border:2px solid color-mix(in srgb,currentColor 16%,transparent);border-top-color:var(--dsw-alias-state-business-primary,#4d6bfe);animation:dsh-sh-spin .8s linear infinite;}",
      ".dsh-sh-progress-text{font-size:12.5px;}",
      ".dsh-sh-progress-elapsed{font-size:11px;color:var(--dsw-alias-label-tertiary,#8a8f98);font-variant-numeric:tabular-nums;}",
      ".dsh-sh-progress-hint{max-width:360px;font-size:10.5px;line-height:1.6;color:var(--dsw-alias-label-tertiary,#8a8f98);}",
      ".dsh-sh-toast{position:fixed;left:50%;bottom:34px;transform:translateX(-50%);z-index:2400;display:flex;align-items:center;gap:12px;padding:9px 14px;border-radius:10px;background:var(--dsw-alias-bg-inverse-platform,#1f2329);color:var(--dsw-alias-label-inverse,#fff);font-size:12px;box-shadow:0 12px 32px rgba(0,0,0,.28);}",
      ".dsh-sh-toast button{border:0;background:transparent;color:var(--dsw-alias-state-business-primary-on-inverse,#8ab4ff);font-size:12px;cursor:pointer;padding:0;}",
      ".dsh-sh-toast .dsh-sh-dismiss{color:inherit;opacity:.6;}"
    ].join("");

    function ensureStyle() {
      if (typeof document === "undefined") return () => {};
      const id = "dsh-session-handoff-style";
      if (document.getElementById(id) !== null) return () => {};
      const element = document.createElement("style");
      element.id = id;
      element.textContent = CSS;
      document.head.appendChild(element);
      return () => {
        element.remove();
      };
    }

    /** 工具条按钮上的字形：一个指向右侧容器的箭头。 */
    function SendGlyph({ size }) {
      const box = typeof size === "number" ? size : 16;
      return h(
        "svg",
        {
          width: box,
          height: box,
          viewBox: "0 0 16 16",
          fill: "none",
          stroke: "currentColor",
          strokeWidth: 1.3,
          strokeLinecap: "round",
          strokeLinejoin: "round",
          "aria-hidden": "true",
          focusable: "false",
          style: { display: "block" }
        },
        h("path", { d: "M9.2 3.2h3.2c.5 0 .9.4.9.9v7.8c0 .5-.4.9-.9.9H9.2" }),
        h("path", { d: "M2.6 8h7.2" }),
        h("path", { d: "M7.3 5.5 9.9 8l-2.6 2.5" })
      );
    }

    function Chevron({ open }) {
      return h(
        "span",
        { className: open ? "dsh-sh-chev open" : "dsh-sh-chev" },
        h(
          "svg",
          { width: 12, height: 12, viewBox: "0 0 12 12", fill: "none", "aria-hidden": "true" },
          h("path", {
            d: "M4.5 2.5 8 6l-3.5 3.5",
            stroke: "currentColor",
            strokeWidth: 1.4,
            strokeLinecap: "round",
            strokeLinejoin: "round"
          })
        )
      );
    }

    function SearchGlyph() {
      return h(
        "svg",
        { width: 14, height: 14, viewBox: "0 0 16 16", fill: "none", "aria-hidden": "true" },
        h("circle", { cx: 7, cy: 7, r: 4.4, stroke: "currentColor", strokeWidth: 1.4 }),
        h("path", { d: "m10.4 10.4 3 3", stroke: "currentColor", strokeWidth: 1.4, strokeLinecap: "round" })
      );
    }

    /** 助手回复工具条上的入口按钮。 */
    function HandoffButton(props) {
      const sessionId = typeof props.sessionId === "string" ? props.sessionId : "";
      const messageId = typeof props.messageId === "string" ? props.messageId : "";
      const label = tr("action");
      const disabled = sessionId.length === 0 || messageId.length === 0;
      return h(
        "button",
        {
          type: "button",
          className: "dsh-sh-action",
          title: tr("actionTitle"),
          "aria-label": label,
          disabled,
          onClick: () => openDialog(sessionId, messageId)
        },
        h(SendGlyph, { size: 15 })
      );
    }

    let openToken = 0;

    /** 打开时只展开当前会话所在的工作区，其余收起。 */
    function collapsedFor(groups, currentId) {
      const collapsed = {};
      let expandedOne = false;
      for (const group of groups) {
        if (group.id === currentId) {
          expandedOne = true;
          continue;
        }
        collapsed[group.id] = true;
      }
      if (!expandedOne && groups.length > 0) delete collapsed[groups[0].id];
      return collapsed;
    }

    function currentGroupOf(groups, sessionId) {
      for (const group of groups) {
        if ((group.sessions ?? []).some((session) => session.sessionId === sessionId)) return group.id;
      }
      return "";
    }

    async function openDialog(sessionId, messageId) {
      const token = ++openToken;
      dialogState.set({ ...emptyDialog, open: true, sessionId, messageId, loading: true });
      try {
        const result = await call("targets");
        if (token !== openToken) return;
        if (result === undefined || result === null) {
          dialogState.set({
            ...dialogState.get(),
            loading: false,
            groups: [],
            stats: null,
            error: tr("emptyResponse")
          });
          return;
        }
        if (result.error !== undefined && result.error !== null) {
          dialogState.set({
            ...dialogState.get(),
            loading: false,
            groups: [],
            stats: null,
            error: `${tr("failed")}：${String(result.error.message ?? result.error)}`
          });
          return;
        }
        const groups = Array.isArray(result.groups) ? result.groups : [];
        // 空列表本身可能是正常的（真的没有会话）；只有连 stats 都没有，才说明
        // 拿到的不是这一版 Host 的结果。
        if (groups.length === 0 && result.stats === undefined) {
          console.warn("session-handoff: 主机返回了无法识别的结果", result);
          dialogState.set({
            ...dialogState.get(),
            loading: false,
            groups: [],
            stats: result?.stats ?? null,
            error: `${tr("unexpected")}：${JSON.stringify(result).slice(0, 160)}`
          });
          return;
        }
        dialogState.set({
          ...dialogState.get(),
          loading: false,
          groups,
          stats: result.stats ?? null,
          collapsed: collapsedFor(groups, currentGroupOf(groups, sessionId))
        });
        hydrateTitles(token, groups);
      } catch (error) {
        if (token !== openToken) return;
        dialogState.set({ ...dialogState.get(), loading: false, groups: [], error: String(error?.message ?? error) });
      }
    }

    /** 冷会话的标题要读日志才有：列表先渲染，标题回来再原地替换。 */
    async function hydrateTitles(token, groups) {
      const unknown = [];
      for (const group of Array.isArray(groups) ? groups : []) {
        for (const session of Array.isArray(group.sessions) ? group.sessions : []) {
          if (session.titleKnown !== true) unknown.push(session.sessionId);
        }
      }
      if (unknown.length === 0) return;
      try {
        const result = await call("titles", { sessionIds: unknown });
        if (token !== openToken) return;
        const titles = result?.titles ?? {};
        const state = dialogState.get();
        const next = (Array.isArray(state.groups) ? state.groups : []).map((group) => ({
          ...group,
          sessions: (Array.isArray(group.sessions) ? group.sessions : []).map((session) =>
            typeof titles[session.sessionId] === "string"
              ? { ...session, title: titles[session.sessionId], titleKnown: true }
              : session
          )
        }));
        dialogState.set({ ...state, groups: next });
      } catch (error) {
        console.warn("session-handoff: 补充会话标题失败", error);
      }
    }

    function closeDialog() {
      const current = dialogState.get();
      if (current.sending) return;
      dialogState.set({ ...current, open: false });
    }

    function toggleGroup(groupId) {
      const state = dialogState.get();
      if (state.query.trim().length > 0) return;
      const collapsed = { ...(state.collapsed ?? {}) };
      if (collapsed[groupId] === true) delete collapsed[groupId];
      else collapsed[groupId] = true;
      dialogState.set({ ...state, collapsed });
    }

    async function submit(target, label, queued) {
      const state = dialogState.get();
      if (state.sending) return;
      dialogState.set({ ...state, sending: true, sendingSince: Date.now(), error: null });
      try {
        let destination = target;
        if (target.kind === "new") {
          // 两段式：先建空会话并切过去，让它成为「当前空白会话」，
          // 侧栏手动顺序就会把它排到工作区最前；之后再让 Host 投递内容。
          const created = await call("create", { workspaceId: target.workspaceId });
          destination = { kind: "new", workspaceId: target.workspaceId, sessionId: created.sessionId };
          await openFresh(created.sessionId);
        }
        const result = await call("send", {
          sourceSessionId: state.sessionId,
          messageId: state.messageId,
          target: destination
        });
        dialogState.set({ ...dialogState.get(), sending: false, open: false });
        const baseText =
          target.kind === "new"
            ? tr("sentNew")
            : queued === true
              ? tr("sentQueued", { title: label })
              : tr("sentTo", { title: label });
        const spent = typeof result?.timings?.total === "number" ? result.timings.total : 0;
        const withTime = spent > 3000 ? `${baseText}（${(spent / 1000).toFixed(1)}s）` : baseText;
        showToast({ text: withTime, sessionId: result.sessionId });
        const focused = await focusSession(result.sessionId);
        if (!focused) showToast({ text: `${withTime}（${tr("openManually")}）`, sessionId: result.sessionId });
      } catch (error) {
        dialogState.set({
          ...dialogState.get(),
          sending: false,
          error: `${tr("failed")}：${String(error?.message ?? error)}`
        });
      }
    }

    function SessionRow({ session, disabled, onPick }) {
      return h(
        "button",
        {
          type: "button",
          className: "dsh-sh-row",
          disabled,
          onClick: () => onPick(session)
        },
        h(
          "span",
          { className: "dsh-sh-row-main" },
          h("div", { className: "dsh-sh-row-title" }, session.title),
          h(
            "div",
            { className: "dsh-sh-row-meta" },
            session.running === true ? h("span", { className: "dsh-sh-dot" }, tr("running")) : null,
            h("span", null, relativeTime(session.updatedAt))
          )
        )
      );
    }

    function HandoffDialog() {
      const state = useStore(dialogState);
      const [tick, setTick] = React.useState(0);
      React.useEffect(() => {
        if (state.open !== true || state.sending !== true) return undefined;
        const timer = window.setInterval(() => setTick((value) => value + 1), 500);
        return () => window.clearInterval(timer);
      }, [state.open, state.sending]);
      React.useEffect(() => {
        if (!state.open) return undefined;
        const onKey = (event) => {
          if (event.key === "Escape") closeDialog();
        };
        window.addEventListener("keydown", onKey);
        return () => window.removeEventListener("keydown", onKey);
      }, [state.open]);

      if (!state.open) return null;

      const groups = Array.isArray(state.groups) ? state.groups : [];
      const collapsed = state.collapsed ?? {};
      const query = state.query.trim().toLowerCase();
      const searching = query.length > 0;
      const disabled = state.sending === true;

      const blocks = [];
      for (const group of groups) {
        const sessions = (Array.isArray(group.sessions) ? group.sessions : []).filter((session) =>
          searching ? String(session.title ?? "").toLowerCase().includes(query) : true
        );
        if (searching && sessions.length === 0) continue;
        const open = searching || collapsed[group.id] !== true;
        blocks.push(
          h(
            "div",
            { key: group.id || "loose", className: "dsh-sh-group" },
            h(
              "button",
              {
                type: "button",
                className: "dsh-sh-grouphead",
                "aria-expanded": open,
                title: open ? tr("collapse") : tr("expand"),
                onClick: () => toggleGroup(group.id)
              },
              h(Chevron, { open }),
              h("span", { className: "dsh-sh-gname" }, group.title || tr("newSession")),
              h("span", { className: "dsh-sh-gpath" }, group.path ?? ""),
              h("span", { className: "dsh-sh-gcount" }, String(sessions.length))
            ),
            open
              ? h(
                  "div",
                  { className: "dsh-sh-rows" },
                  h(
                    "button",
                    {
                      type: "button",
                      className: "dsh-sh-newrow",
                      disabled: disabled || state.loading === true,
                      onClick: () =>
                        submit(
                          { kind: "new", workspaceId: typeof group.id === "string" ? group.id : "" },
                          tr("newSession")
                        )
                    },
                    h("span", { "aria-hidden": "true" }, "＋"),
                    h("span", null, disabled ? tr("sending") : tr("newSessionIn"))
                  ),
                  sessions.slice(0, PER_GROUP_LIMIT).map((session) =>
                    h(SessionRow, {
                      key: session.sessionId,
                      session,
                      disabled,
                      onPick: (picked) =>
                        submit({ kind: "existing", sessionId: picked.sessionId }, picked.title, picked.running === true)
                    })
                  ),
                  sessions.length > PER_GROUP_LIMIT
                    ? h(
                        "div",
                        { className: "dsh-sh-more" },
                        tr("moreSessions", { n: sessions.length - PER_GROUP_LIMIT })
                      )
                    : null
                )
              : null
          )
        );
      }

      const stats = state.stats;
      return h(
        "div",
        {
          className: "dsh-sh-backdrop",
          onMouseDown: (event) => {
            if (event.target === event.currentTarget) closeDialog();
          }
        },
        h(
          "div",
          { className: "dsh-sh-dialog", role: "dialog", "aria-modal": "true", "aria-label": tr("dialogTitle") },
          h(
            "div",
            { className: "dsh-sh-head" },
            h("h2", null, tr("dialogTitle")),
            h(
              "button",
              { type: "button", className: "dsh-sh-close", onClick: closeDialog, "aria-label": tr("close") },
              "×"
            )
          ),
          h(
            "div",
            { className: "dsh-sh-searchwrap" },
            h("span", { className: "dsh-sh-searchicon" }, h(SearchGlyph, null)),
            h("input", {
              className: "dsh-sh-search",
              placeholder: tr("search"),
              autoFocus: true,
              value: state.query,
              disabled,
              onChange: (event) => dialogState.set({ ...dialogState.get(), query: event.target.value })
            })
          ),
          state.error === null || state.error === undefined
            ? null
            : h("div", { className: "dsh-sh-error" }, state.error),
          state.sending === true
            ? h(
                "div",
                { className: "dsh-sh-progress", role: "status", "aria-live": "polite" },
                h("div", { className: "dsh-sh-spinner" }),
                h("div", { className: "dsh-sh-progress-text" }, tr("preparing")),
                h(
                  "div",
                  { className: "dsh-sh-progress-elapsed" },
                  tr("elapsed", {
                    n: Math.max(0, Math.round((Date.now() - (state.sendingSince || Date.now())) / 1000))
                  })
                ),
                h("div", { className: "dsh-sh-progress-hint" }, tr("preparingHint"))
              )
            : h(
            "div",
            { className: "dsh-sh-list" },
            state.loading === true ? h("div", { className: "dsh-sh-empty" }, tr("loading")) : null,
            state.loading !== true && blocks.length === 0
              ? h(
                  "div",
                  { className: "dsh-sh-empty" },
                  searching ? tr("empty") : tr("noTargets"),
                  !searching && stats !== null && stats !== undefined
                    ? h(
                        "div",
                        { style: { marginTop: 6, fontSize: 10.5, opacity: 0.8 } },
                        tr("diag", {
                          listed: stats.listed ?? 0,
                          records: stats.records ?? 0,
                          blank: stats.skipped?.blank ?? 0,
                          archived: stats.skipped?.archived ?? 0,
                          subagent: stats.skipped?.subagent ?? 0
                        })
                      )
                    : null
                )
              : null,
            blocks
          ),
          h(
            "div",
            { className: "dsh-sh-foot" },
            h("span", { className: "dsh-sh-foot-hint" }, tr("hint")),
            stats === null || stats === undefined
              ? null
              : h(
                  "span",
                  { className: "dsh-sh-foot-stats" },
                  tr("stats", { sessions: stats.sessions ?? 0, workspaces: stats.workspaces ?? 0 })
                ),
            h("span", { className: "dsh-sh-foot-build" }, `v${BUILD}`)
          )
        )
      );
    }

    function HandoffToast() {
      const toast = useStore(toastState);
      if (toast === null || toast === undefined) return null;
      return h(
        "div",
        { className: "dsh-sh-toast", role: "status" },
        h("span", null, toast.text),
        h("button", { type: "button", onClick: () => focusSession(toast.sessionId) }, tr("open")),
        h(
          "button",
          {
            type: "button",
            className: "dsh-sh-dismiss",
            "aria-label": tr("dismiss"),
            onClick: () => toastState.set(null)
          },
          "×"
        )
      );
    }

    function apply(ctx) {
      ctxRef = ctx;
      try {
        mountReady = ctx.remote.$mount(REMOTE);
      } catch (error) {
        console.warn("session-handoff: Remote 挂载失败", error);
      }

      const locale = ctx.get("locale");
      if (locale !== undefined && locale !== null) {
        ctx.effect(() => locale.register(NS, DICT));
        tRef = locale.bind(NS);
      }

      const slots = ctx.get("slots");
      if (slots === undefined) return;
      ctx.effect(() => ensureStyle());

      slots.inject("conversation.chat.assistant-actions", () =>
        slots.register(
          {
            name: "conversation.chat.assistant-actions",
            id: "session-handoff",
            order: 20,
            locale: NS,
            inject: (sessionId) => ({ sessionId })
          },
          HandoffButton
        )
      );

      slots.inject("shell.overlay", () =>
        slots.register({ name: "shell.overlay", id: "session-handoff-dialog", order: 70, locale: NS }, HandoffDialog)
      );

      slots.inject("shell.overlay", () =>
        slots.register({ name: "shell.overlay", id: "session-handoff-toast", order: 71, locale: NS }, HandoffToast)
      );
    }

    exports.apply = apply;
    exports.inject = ["slots", "remote", "locale", "uiWorkspace"];
    return module.exports;
  }
});
