#!/usr/bin/env node
// 从 OpenCode 官方文档的 Go 价格表生成客户端内嵌的月度额度数据。
//
// 数据源（都是公开页面，不需要 API Key）：
//   - https://opencode.ai/docs/console/go.md          → 每模型 Monthly limit（Go / Go Plus / Go Teams）
//   - https://opencode.ai/inference/go/v1/models      → 模型 id / name，用来把文档里的名字映射成稳定 id
//
// 用法：
//   node scripts/sync-limits.mjs              # 抓线上文档并改 client.js
//   node scripts/sync-limits.mjs --fixture    # 用 test/fixtures 下的快照（离线/测试）
//   node scripts/sync-limits.mjs --check      # 只检查是否与线上一致，不改文件
//
// 客户端 bundle 必须自包含（不能相对 require 另一个 client 产物），
// 所以数据直接写进 client.js 的 generated 区块，而不是单独的 JSON 文件。
import { readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const CLIENT = join(ROOT, "client.js");
const DOCS_URL = "https://opencode.ai/docs/console/go.md";
const MODELS_URL = "https://opencode.ai/inference/go/v1/models";
const FIXTURE_MD = join(ROOT, "test/fixtures/go.md");
const FIXTURE_MODELS = join(ROOT, "test/fixtures/models.json");

export const PLAN_ORDER = ["go", "go-plus", "go-teams"];
export const PLAN_LABELS = { go: "Go", "go-plus": "Go Plus", "go-teams": "Go Teams" };
export const BEGIN_MARKER = "// >>> generated:limits";
export const END_MARKER = "// <<< generated:limits";
const DEFAULT_PLAN = "go";

/**
 * 把模型名归一化成可比较的 key。
 * 文档里的拆分行（Peak/Off-Peak、≤/> 512K tokens、50% off）去掉括号后
 * 与 models 接口的 name 对齐。
 * @param {string} value
 * @returns {string}
 */
export function normalizeName(value) {
  return String(value)
    .toLowerCase()
    .replace(/\([^)]*\)/g, " ")
    .replace(/（[^）]*）/g, " ")
    .replace(/[^a-z0-9.]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
}

/**
 * 解析一个 "Monthly limit" 表格块。
 * @param {string} body 一个 `<div slot="go...">` 的内容
 * @returns {Map<string, {usd: number}|{unlimited: true}>}
 */
function parseTable(body) {
  const rows = new Map();
  for (const line of body.split("\n")) {
    const cells = line.split("|").map((cell) => cell.trim());
    if (cells.length < 8) continue;
    const model = cells[1];
    if (model === "" || /^-+$/.test(model) || model === "Model") continue;
    let limit = cells[6] ?? "";
    const bold = limit.match(/\*\*(.+?)\*\*/);
    if (bold) limit = bold[1];
    limit = limit.replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
    if (limit === "") continue;
    const key = normalizeName(model);
    if (key === "") continue;
    let value;
    if (/^unlimited\b/i.test(limit)) {
      value = { unlimited: true };
    } else {
      const usd = limit.match(/\$\s*([\d.]+)/);
      if (!usd) continue;
      value = { usd: Number(usd[1]) };
    }
    // Peak/Off-Peak 等拆分行共享同一个额度；若官方真的给出不同值，保留第一个并提示。
    if (!rows.has(key)) rows.set(key, value);
    else if (JSON.stringify(rows.get(key)) !== JSON.stringify(value)) {
      console.warn(`warn: ${key} 在文档中有多个不同额度，保留 ${JSON.stringify(rows.get(key))}`);
    }
  }
  return rows;
}

/**
 * 从 docs markdown 里解析三档套餐的 Monthly limit 表。
 * @param {string} markdown
 * @returns {Record<string, Map<string, {usd: number}|{unlimited: true}>>}
 */
export function parseMonthlyLimits(markdown) {
  /** @type {Record<string, Map<string, {usd: number}|{unlimited: true}>>} */
  const plans = {};
  const seen = new Set();
  for (const match of markdown.matchAll(/<div slot="(go(?:-plus|-teams)?)">([\s\S]*?)<\/div>/g)) {
    const [, plan, body] = match;
    // 文档里还有 "Estimated requests" 等同样使用 PlanTabs 的表，只取带 Monthly limit 的。
    if (!/Monthly limit/.test(body)) continue;
    // 每个套餐只取第一次出现的价格表。
    if (seen.has(plan)) continue;
    seen.add(plan);
    plans[plan] = parseTable(body);
  }
  for (const plan of PLAN_ORDER) {
    if (!plans[plan]) throw new Error(`文档里找不到套餐 ${plan} 的 Monthly limit 表`);
  }
  return plans;
}

/**
 * 把文档里的模型名映射到 models 接口的 id。
 * @param {Record<string, Map<string, object>>} plans
 * @param {Array<{id: string, name: string}>} models
 * @returns {{ plans: Record<string, {byId: Record<string, object>, byName: Record<string, object>}>, unmatchedDocs: string[], unmatchedModels: string[] }}
 */
export function mapLimits(plans, models) {
  const apiByNorm = new Map();
  for (const model of models) {
    const key = normalizeName(model.name);
    if (!apiByNorm.has(key)) apiByNorm.set(key, model);
  }
  /** @type {Record<string, {byId: Record<string, object>, byName: Record<string, object>}>} */
  const mapped = {};
  const unmatchedDocs = new Set();
  const matchedIds = new Set();
  for (const plan of PLAN_ORDER) {
    const byId = {};
    const byName = {};
    const entries = [...plans[plan].entries()].sort(([a], [b]) => a.localeCompare(b));
    for (const [name, value] of entries) {
      byName[name] = value;
      const model = apiByNorm.get(name);
      if (model === undefined) {
        unmatchedDocs.add(name);
        continue;
      }
      byId[model.id] = value;
      matchedIds.add(model.id);
    }
    mapped[plan] = { byId, byName };
  }
  const unmatchedModels = models.filter((model) => !matchedIds.has(model.id)).map((model) => model.id);
  return { plans: mapped, unmatchedDocs: [...unmatchedDocs].sort(), unmatchedModels };
}

/**
 * 生成 client.js 里的数据区块（不含首尾标记）。
 * @param {{plans: object}} data
 * @param {{source?: string, modelsSource?: string, generatedAt?: string}} meta
 * @returns {string}
 */
export function renderDataBlock(data, meta) {
  const info = {
    source: meta.source ?? DOCS_URL,
    modelsSource: meta.modelsSource ?? MODELS_URL,
    generatedAt: meta.generatedAt ?? new Date().toISOString(),
  };
  /** 用 tab 缩进 JSON，并把续行对齐到区块的缩进。 */
  const embed = (value) => JSON.stringify(value, null, "  ").split("\n").join("\n    ");
  const lines = [
    `${BEGIN_MARKER} (scripts/sync-limits.mjs)`,
    "/** 默认展示的套餐；Go Plus / Go Teams 用户改成对应 key 即可。 */",
    `const DEFAULT_PLAN = ${JSON.stringify(DEFAULT_PLAN)};`,
    `const PLAN_ORDER = ${JSON.stringify(PLAN_ORDER).replaceAll(",", ", ")};`,
    `const PLAN_LABELS = ${JSON.stringify(PLAN_LABELS).replaceAll(",", ", ").replaceAll(":", ": ")};`,
    "/** 文档 table → { byId: 模型 id → 额度, byName: 归一化名称 → 额度 }。 */",
    `const LIMITS = ${embed(data.plans)};`,
    `const LIMITS_META = ${embed(info)};`,
    END_MARKER,
  ];
  return lines.map((line) => `    ${line}`).join("\n");
}

/** 替换 client.js 里的 generated 区块。 */
export function applyBlock(source, block) {
  const pattern = /^[ \t]*\/\/ >>> generated:limits[\s\S]*?^[ \t]*\/\/ <<< generated:limits/m;
  if (!pattern.test(source)) throw new Error("client.js 里找不到 generated:limits 标记");
  return source.replace(pattern, () => block);
}

/** 只比较额度数据，忽略抓取时间。 */
function stableBlock(block) {
  return block.replace(/(?:"generatedAt"|generatedAt)\s*:\s*"[^"]*"/, '"generatedAt": "<ignored>"');
}

async function fetchText(url) {
  let lastError;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      const response = await fetch(url, {
        headers: { Accept: "text/plain, application/json, */*", "User-Agent": "dsh-go-model-limits-sync" },
        signal: AbortSignal.timeout(20000),
      });
      if (!response.ok) throw new Error(`${url} → HTTP ${response.status}`);
      return await response.text();
    } catch (error) {
      lastError = error;
      if (attempt < 2) await new Promise((resolve) => setTimeout(resolve, 800));
    }
  }
  throw lastError;
}

async function main() {
  const args = new Set(process.argv.slice(2));
  let markdown;
  let models;
  if (args.has("--fixture")) {
    markdown = readFileSync(FIXTURE_MD, "utf8");
    models = JSON.parse(readFileSync(FIXTURE_MODELS, "utf8")).data;
  } else {
    markdown = await fetchText(DOCS_URL);
    models = JSON.parse(await fetchText(MODELS_URL)).data;
  }
  const parsed = parseMonthlyLimits(markdown);
  const mapped = mapLimits(parsed, models);
  const block = renderDataBlock(mapped, { generatedAt: new Date().toISOString() });
  if (mapped.unmatchedDocs.length > 0) {
    console.warn(`warn: 文档里有 ${mapped.unmatchedDocs.length} 个名称在当前 Go 模型列表中不存在：${mapped.unmatchedDocs.join(", ")}`);
  }
  if (mapped.unmatchedModels.length > 0) {
    console.warn(`warn: 当前列表里有 ${mapped.unmatchedModels.length} 个模型没有文档额度：${mapped.unmatchedModels.join(", ")}`);
  }
  const source = readFileSync(CLIENT, "utf8");
  if (args.has("--check")) {
    const current = source.match(/^[ \t]*\/\/ >>> generated:limits[\s\S]*?^[ \t]*\/\/ <<< generated:limits/m)?.[0];
    if (current === undefined) throw new Error("client.js 里找不到 generated:limits 标记");
    if (stableBlock(current) !== stableBlock(block)) {
      console.error("generated 区块与线上数据不一致，请运行 node scripts/sync-limits.mjs");
      process.exit(1);
    }
    console.log("generated 区块与线上数据一致");
    return;
  }
  writeFileSync(CLIENT, applyBlock(source, block));
  const counts = PLAN_ORDER.map((plan) => `${plan}: ${Object.keys(mapped.plans[plan].byId).length}`).join(", ");
  console.log(`已更新 client.js（${counts}）`);
}

const isMain = process.argv[1] !== undefined && pathToFileURL(process.argv[1]).href === import.meta.url;
if (isMain) {
  await main();
}
