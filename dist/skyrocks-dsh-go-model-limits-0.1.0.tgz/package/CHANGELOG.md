# Changelog

All notable changes to this project are documented here.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [0.1.0] - 2026-11-09

### Added

- First release: show the official OpenCode GO **Monthly limit** on each `opencode-go`
  model row in the DeepSeek Harness model picker.
- Hover tooltip with the Go / Go Plus / Go Teams limits and the data generation date.
- Colour-coded tags: `<$30` amber, `$30–$99` blue, `≥$100` green, unlimited violet.
- `scripts/sync-limits.mjs` builds the embedded data from
  `https://opencode.ai/docs/console/go.md` and `https://opencode.ai/inference/go/v1/models`.
- Official account and other providers keep their original name and badge; only the
  composer list rows of `opencode-go` get a tag.
- Zero runtime dependencies, no runtime network access, no API key.
- Tests: docs parsing, name→id mapping, component rendering, manifest and bundle checks.
- README (zh/en) with illustrations, CI workflow and publishing checklist.
