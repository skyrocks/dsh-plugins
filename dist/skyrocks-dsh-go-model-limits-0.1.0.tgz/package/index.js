/**
 * Host 半：纯浏览器 UI 插件。
 *
 * 这里只需要一个空的 apply，让插件出现在 host 的 cordis.yml / Loader 里；
 * 真正的界面在 `client.js`，由 package.json 的 `dsh.client` 声明发现。
 */
export function apply() {}
