# Go

OpenCode Go gives you reliable access to popular open coding models, with three monthly plans:

| Plan         | Price                | Included usage                                                             |
| ------------ | -------------------- | -------------------------------------------------------------------------- |
| **Go**       | **$10/month**        | Lower-cost access to the models below                                      |
| **Go Plus**  | **$40/month**        | Higher usage limits across the models below                                |
| **Go Teams** | **$20/member/month** | Every member gets their own limits, $5/month higher than Go on every model |

Go works like any other provider in OpenCode. You subscribe to OpenCode Go and get your API key. It's **completely optional** and you don't need it to use OpenCode.

The service is designed primarily for international users and provides stable global access.

## How it works

1. Sign in to the [OpenCode Console](https://opencode.ai/console), subscribe to Go, Go Plus, or Go Teams, add your billing details, and copy your API key.
2. Run `/connect` in the TUI, select **OpenCode Go**, and paste your API key.

   ```text
   /connect
   ```

3. Run `/models` to select a model available through Go.

   ```text
   /models
   ```

<Callout>
  Go and Go Plus are for workspaces with a single member, such as the **Personal** workspace created when you sign up.
  Either can upgrade to Go Teams at any time, with the unused part of the month's allowance credited. Go Teams covers
  every member of a workspace with several members, at $20 per member per month. A member who joins mid-period is
  charged $20 and gets a full monthly allowance. Service accounts are not covered by Go Teams.
</Callout>

The current list of models includes:

- **Grok 4.7**
- **GLM-5.3-Flash**
- **GLM-5.3**
- **GLM-5.2**
- **GPT 6 Luna**
- **GPT 5.6 Luna**
- **Claude Haiku 5.5**
- **Gemini 4 Argon**
- **Kimi K3.1 Pro**
- **Kimi K3**
- **Kimi K2.7 Code**
- **LongCat-2.0**
- **Step 5 Preview**
- **Crouton Alpha Free** (limited time, limited regions)
- **Beam Free** (limited time, limited regions)
- **Iceman Contributor Free** (limited time)
- **MiMo-V2.6-Flash**
- **MiMo-V2.6-Pro**
- **MiMo-V2.5**
- **MiMo-V2.5-Pro**
- **MiniMax M3.1 Flash**
- **MiniMax M3**
- **Muse Spark 1.3 Contributor** ([limited regions](https://ai.developer.meta.com/legal/geographic-use-policy))
- **Muse Spark 1.2 Contributor** ([limited regions](https://ai.developer.meta.com/legal/geographic-use-policy))
- **Qwen3.8 Max**
- **Qwen3.8 Flash**
- **Qwen3.7 Plus**
- **DeepSeek V4.1 Flash**
- **DeepSeek V4 Pro**
- **Hy4**
- **Hy4 preview**
- **Hy3**

The list of models may change as we test and add new ones.

### Enable restricted models

Workspace privacy settings apply to Go. By default, paid endpoints that train on request data are blocked, and
allowed regions are **Europe & United States**. Workspaces without saved privacy settings also allow **Global**
for requests from China.

In **Settings › Privacy**, an owner or admin can enable:

- **DeepSeek V4.1 Flash and V4 Pro:** select **Global** under **Regions**.
- **Muse Spark 1.3 Contributor and Muse Spark 1.2 Contributor:** turn on **Allow paid endpoints that train on request data**.

See [Privacy](#privacy) for each model's training and retention terms.

## Where can I use it?

OpenCode Go is designed for [OpenCode](https://opencode.ai) and other coding agents
that produce similar types of requests. Traffic is monitored for abuse that
degrades the experience for other users.

Your client should:

1. Send typical coding agent traffic
2. Identify itself with its own user agent, such as `my-coding-agent/1.0`, rather
   than a generic SDK or HTTP-library name.
3. Send a stable session ID in `x-opencode-session` for each conversation so we can optimize routing and
   prompt caching.

See [Harnesses](/console/harnesses) to set up Go in Claude Code, Codex, Hermes, Pi, and Raycast.

### Validated clients

Besides OpenCode, the following clients have been validated to work properly
with OpenCode Go, although we do not guarantee that they will continue to work in the future.

| Client            | Session support                                                                                                                                                                                                                             |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Hermes**        | Update to **v0.21.6 or later**, which sends the header on main and auxiliary OpenCode requests ([PR #101864](https://github.com/NousResearch/hermes-agent/pull/101864)).                                                                    |
| **Claude Code**   | Go recognizes its native session header. No custom-header wrapper is needed.                                                                                                                                                                |
| **Codex**         | Go recognizes its native session header. Some versions and proxy setups still omit it; preserve the session header when forwarding requests.                                                                                                |
| **ZCode**         | Go recognizes its native session header. Our [request for `x-opencode-session`](https://github.com/zai-org/feedback/issues/492) remains open, but it is no longer necessary to send that specific header.                                   |
| **Pi**            | Current builds send session information for OpenCode. Update older installations.                                                                                                                                                           |
| **jcode**         | Update to **v0.81.6 or later**, which includes the [session-header fix](https://github.com/1jehuang/jcode/issues/1167).                                                                                                                     |
| **Kilo Code CLI** | Builds containing [PR #13752](https://github.com/Kilo-Org/kilocode/pull/13752) restore OpenCode session headers. This fix covers the CLI, not the VS Code extension. See [issue #13723](https://github.com/Kilo-Org/kilocode/issues/13723). |

### Known problematic clients

These clients have missing or incomplete session support in the versions we
investigated. The linked reports track fixes and workarounds.

| Client                  | Status and tracking                                                                                                                                                                                                                                    |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **DeepSeek Harness**    | Session information arrives on some model paths, but is missing on others. We recognize its native header; the remaining work is to send it across all adapters. [Discussion #5495](https://github.com/deepseek-ai/deepseek-harness/discussions/5495). |
| **GitHub Copilot Chat** | Automatic session-header support is requested in [VS Code issue #334186](https://github.com/microsoft/vscode/issues/334186).                                                                                                                           |
| **Kimi Code**           | The session-header request in [issue #3506](https://github.com/MoonshotAI/kimi-code/issues/3506) was closed as not planned.                                                                                                                            |
| **MiMo Code**           | [Issue #2317](https://github.com/XiaomiMiMo/MiMo-Code/issues/2317) is closed, and [PR #2327](https://github.com/XiaomiMiMo/MiMo-Code/pull/2327) was closed without merging.                                                                            |

## Usage limits

Usage limits are defined as monthly dollar amounts. The table below shows the
monthly limit for each plan and the token costs for each model. Token pricing is
the same for Go, Go Plus, and Go Teams.

Each model has the following usage limits: 5-hour — 20% of the monthly limit;
weekly — 50%; and monthly — 100%.

Each model's monthly limit below determines how its usage counts toward those allowances. Each response reports how
much the request counted, as [`opencode.allowance`](/console/api/inference#cost).

Token prices are per 1M tokens.

<PlanTabs id="go-pricing" label="Go plan" syncKey="go-plan">
  <div slot="go">

    | Model                            | Input           | Output            | Cached Read     | Cached Write | Monthly limit                                  |
    | -------------------------------- | --------------- | ----------------- | --------------- | ------------ | ---------------------------------------------- |
    | GLM-5.3-Flash                    | $0.15           | $0.50             | $0.03           | -            | **$60**                                        |
    | GLM-5.3                          | $1.40           | $4.40             | $0.26           | -            | **$15**                                        |
    | GLM-5.2                          | $1.40           | $4.40             | $0.26           | -            | **$60**                                        |
    | Kimi K3.1 Pro                    | $2.00           | $10.00            | $0.20           | $2.00        | **$15**                                        |
    | Kimi K3                          | $3.00           | $15.00            | $0.30           | $3.00        | **$15**                                        |
    | Kimi K2.7 Code                   | $0.95           | $4.00             | $0.19           | -            | **$60**                                        |
    | LongCat-2.0                      | $0.30           | $1.20             | $0.006          | -            | **$60**                                        |
    | Step 5 Preview                   | $1.00           | $2.70             | $0.10           | -            | **$15**                                        |
    | Crouton Alpha Free               | Free            | Free              | Free            | -            | **Unlimited**<br /><small>limited time</small> |
    | Beam Free                        | Free            | Free              | Free            | -            | **Unlimited**<br /><small>limited time</small> |
    | Iceman Contributor Free          | Free            | Free              | Free            | -            | **Unlimited**<br /><small>limited time</small> |
    | MiMo-V2.6-Flash                  | $0.14           | $0.28             | $0.0028         | -            | **$60**                                        |
    | MiMo-V2.6-Pro                    | $0.435          | $0.87             | $0.003625       | -            | **$15**                                        |
    | MiMo-V2.5                        | $0.14           | $0.28             | $0.0028         | -            | **$60**                                        |
    | MiMo-V2.5-Pro                    | $0.435          | $0.87             | $0.003625       | -            | **$15**                                        |
    | MiniMax M3.1 Flash               | $0.15           | $0.60             | $0.015          | -            | **$20**                                        |
    | MiniMax M3 (≤ 512K tokens)       | $0.30           | $1.20             | $0.06           | -            | **$60**                                        |
    | MiniMax M3 (> 512K tokens)       | $0.60           | $2.40             | $0.12           | -            | **$60**                                        |
    | Muse Spark 1.3 Contributor       | $0.10           | $0.20             | $0.002          | -            | **$60**                                        |
    | Muse Spark 1.2 Contributor       | $0.10           | $0.20             | $0.002          | -            | **$60**                                        |
    | Qwen3.8 Max                      | $2.00           | $6.00             | $0.25           | $2.50        | **$15**                                        |
    | Qwen3.8 Flash                    | $0.15           | $0.47             | $0.016          | $0.20        | **$30**                                        |
    | Qwen3.7 Plus (≤ 256K tokens)     | $0.40           | $1.60             | $0.04           | $0.50        | **$60**                                        |
    | Qwen3.7 Plus (> 256K tokens)     | $1.20           | $4.80             | $0.12           | $1.50        | **$60**                                        |
    | DeepSeek V4.1 Flash (Off-Peak)   | $0.15           | $0.60             | $0.003          | -            | **$100**                                       |
    | DeepSeek V4.1 Flash (Peak)       | $0.30           | $1.20             | $0.006          | -            | **$100**                                       |
    | DeepSeek V4 Pro (Off-Peak)       | $0.66           | $1.98             | $0.022          | -            | **$15**                                        |
    | DeepSeek V4 Pro (Peak)           | $1.32           | $3.96             | $0.044          | -            | **$15**                                        |
    | Hy4                              | $0.834          | $2.501            | $0.042          | -            | **$60**                                        |
    | Hy4 preview                      | $0.834          | $2.501            | $0.042          | -            | **$30**                                        |
    | Hy3                              | $0.14           | $0.58             | $0.035          | -            | **$60**                                        |
    | Grok 4.7 (≤ 200K tokens)         | $2.00           | $6.00             | $0.50           | -            | **$15**                                        |
    | Grok 4.7 (> 200K tokens)         | $4.00           | $12.00            | $1.00           | -            | **$15**                                        |
    | GPT 6 Luna (≤ 272K tokens)       | $0.10           | $0.50             | $0.01           | $0.125       | **$15**                                        |
    | GPT 6 Luna (> 272K tokens)       | $0.20           | $0.75             | $0.02           | $0.25        | **$15**                                        |
    | GPT 5.6 Luna (≤ 272K tokens)     | $0.20           | $1.20             | $0.02           | $0.25        | **$15**                                        |
    | GPT 5.6 Luna (> 272K tokens)     | $0.40           | $1.80             | $0.04           | $0.50        | **$15**                                        |
    | Claude Haiku 5.5 (≤ 100K tokens) | $0.10           | $0.50             | $0.01           | $0.125       | **$15**                                        |
    | Claude Haiku 5.5 (> 100K tokens) | $0.50           | $2.50             | $0.05           | $0.625       | **$15**                                        |
    | Gemini 4 Argon (50% off)         | ~~$4.00~~ $2.00 | ~~$20.00~~ $10.00 | ~~$0.20~~ $0.10 | -            | **$30**                                        |

  </div>
  <div slot="go-plus">

    | Model                            | Input           | Output            | Cached Read     | Cached Write | Monthly limit                                  |
    | -------------------------------- | --------------- | ----------------- | --------------- | ------------ | ---------------------------------------------- |
    | GLM-5.3-Flash                    | $0.15           | $0.50             | $0.03           | -            | **$180**                                       |
    | GLM-5.3                          | $1.40           | $4.40             | $0.26           | -            | **$120**                                       |
    | GLM-5.2                          | $1.40           | $4.40             | $0.26           | -            | **$180**                                       |
    | Kimi K3.1 Pro                    | $2.00           | $10.00            | $0.20           | $2.00        | **$60**                                        |
    | Kimi K3                          | $3.00           | $15.00            | $0.30           | $3.00        | **$60**                                        |
    | Kimi K2.7 Code                   | $0.95           | $4.00             | $0.19           | -            | **$180**                                       |
    | LongCat-2.0                      | $0.30           | $1.20             | $0.006          | -            | **$240**                                       |
    | Step 5 Preview                   | $1.00           | $2.70             | $0.10           | -            | **$60**                                        |
    | Crouton Alpha Free               | Free            | Free              | Free            | -            | **Unlimited**<br /><small>limited time</small> |
    | Beam Free                        | Free            | Free              | Free            | -            | **Unlimited**<br /><small>limited time</small> |
    | Iceman Contributor Free          | Free            | Free              | Free            | -            | **Unlimited**<br /><small>limited time</small> |
    | MiMo-V2.6-Flash                  | $0.14           | $0.28             | $0.0028         | -            | **$120**                                       |
    | MiMo-V2.6-Pro                    | $0.435          | $0.87             | $0.003625       | -            | **$60**                                        |
    | MiMo-V2.5                        | $0.14           | $0.28             | $0.0028         | -            | **$120**                                       |
    | MiMo-V2.5-Pro                    | $0.435          | $0.87             | $0.003625       | -            | **$60**                                        |
    | MiniMax M3.1 Flash               | $0.15           | $0.60             | $0.015          | -            | **$80**                                        |
    | MiniMax M3 (≤ 512K tokens)       | $0.30           | $1.20             | $0.06           | -            | **$180**                                       |
    | MiniMax M3 (> 512K tokens)       | $0.60           | $2.40             | $0.12           | -            | **$180**                                       |
    | Muse Spark 1.3 Contributor       | $0.10           | $0.20             | $0.002          | -            | **$120**                                       |
    | Muse Spark 1.2 Contributor       | $0.10           | $0.20             | $0.002          | -            | **$120**                                       |
    | Qwen3.8 Max                      | $2.00           | $6.00             | $0.25           | $2.50        | **$60**                                        |
    | Qwen3.8 Flash                    | $0.15           | $0.47             | $0.016          | $0.20        | **$90**                                        |
    | Qwen3.7 Plus (≤ 256K tokens)     | $0.40           | $1.60             | $0.04           | $0.50        | **$180**                                       |
    | Qwen3.7 Plus (> 256K tokens)     | $1.20           | $4.80             | $0.12           | $1.50        | **$180**                                       |
    | DeepSeek V4.1 Flash (Off-Peak)   | $0.15           | $0.60             | $0.003          | -            | **$200**                                       |
    | DeepSeek V4.1 Flash (Peak)       | $0.30           | $1.20             | $0.006          | -            | **$200**                                       |
    | DeepSeek V4 Pro (Off-Peak)       | $0.66           | $1.98             | $0.022          | -            | **$60**                                        |
    | DeepSeek V4 Pro (Peak)           | $1.32           | $3.96             | $0.044          | -            | **$60**                                        |
    | Hy4                              | $0.834          | $2.501            | $0.042          | -            | **$240**                                       |
    | Hy4 preview                      | $0.834          | $2.501            | $0.042          | -            | **$120**                                       |
    | Hy3                              | $0.14           | $0.58             | $0.035          | -            | **$240**                                       |
    | Grok 4.7 (≤ 200K tokens)         | $2.00           | $6.00             | $0.50           | -            | **$60**                                        |
    | Grok 4.7 (> 200K tokens)         | $4.00           | $12.00            | $1.00           | -            | **$60**                                        |
    | GPT 6 Luna (≤ 272K tokens)       | $0.10           | $0.50             | $0.01           | $0.125       | **$60**                                        |
    | GPT 6 Luna (> 272K tokens)       | $0.20           | $0.75             | $0.02           | $0.25        | **$60**                                        |
    | GPT 5.6 Luna (≤ 272K tokens)     | $0.20           | $1.20             | $0.02           | $0.25        | **$60**                                        |
    | GPT 5.6 Luna (> 272K tokens)     | $0.40           | $1.80             | $0.04           | $0.50        | **$60**                                        |
    | Claude Haiku 5.5 (≤ 100K tokens) | $0.10           | $0.50             | $0.01           | $0.125       | **$60**                                        |
    | Claude Haiku 5.5 (> 100K tokens) | $0.50           | $2.50             | $0.05           | $0.625       | **$60**                                        |
    | Gemini 4 Argon (50% off)         | ~~$4.00~~ $2.00 | ~~$20.00~~ $10.00 | ~~$0.20~~ $0.10 | -            | **$120**                                       |

  </div>
  <div slot="go-teams">

    | Model                            | Input           | Output            | Cached Read     | Cached Write | Monthly limit                                  |
    | -------------------------------- | --------------- | ----------------- | --------------- | ------------ | ---------------------------------------------- |
    | GLM-5.3-Flash                    | $0.15           | $0.50             | $0.03           | -            | **$65**                                        |
    | GLM-5.3                          | $1.40           | $4.40             | $0.26           | -            | **$20**                                        |
    | GLM-5.2                          | $1.40           | $4.40             | $0.26           | -            | **$65**                                        |
    | Kimi K3.1 Pro                    | $2.00           | $10.00            | $0.20           | $2.00        | **$20**                                        |
    | Kimi K3                          | $3.00           | $15.00            | $0.30           | $3.00        | **$20**                                        |
    | Kimi K2.7 Code                   | $0.95           | $4.00             | $0.19           | -            | **$65**                                        |
    | LongCat-2.0                      | $0.30           | $1.20             | $0.006          | -            | **$65**                                        |
    | Step 5 Preview                   | $1.00           | $2.70             | $0.10           | -            | **$20**                                        |
    | Crouton Alpha Free               | Free            | Free              | Free            | -            | **Unlimited**<br /><small>limited time</small> |
    | Beam Free                        | Free            | Free              | Free            | -            | **Unlimited**<br /><small>limited time</small> |
    | Iceman Contributor Free          | Free            | Free              | Free            | -            | **Unlimited**<br /><small>limited time</small> |
    | MiMo-V2.6-Flash                  | $0.14           | $0.28             | $0.0028         | -            | **$65**                                        |
    | MiMo-V2.6-Pro                    | $0.435          | $0.87             | $0.003625       | -            | **$20**                                        |
    | MiMo-V2.5                        | $0.14           | $0.28             | $0.0028         | -            | **$65**                                        |
    | MiMo-V2.5-Pro                    | $0.435          | $0.87             | $0.003625       | -            | **$20**                                        |
    | MiniMax M3.1 Flash               | $0.15           | $0.60             | $0.015          | -            | **$25**                                        |
    | MiniMax M3 (≤ 512K tokens)       | $0.30           | $1.20             | $0.06           | -            | **$65**                                        |
    | MiniMax M3 (> 512K tokens)       | $0.60           | $2.40             | $0.12           | -            | **$65**                                        |
    | Muse Spark 1.3 Contributor       | $0.10           | $0.20             | $0.002          | -            | **$65**                                        |
    | Muse Spark 1.2 Contributor       | $0.10           | $0.20             | $0.002          | -            | **$65**                                        |
    | Qwen3.8 Max                      | $2.00           | $6.00             | $0.25           | $2.50        | **$20**                                        |
    | Qwen3.8 Flash                    | $0.15           | $0.47             | $0.016          | $0.20        | **$35**                                        |
    | Qwen3.7 Plus (≤ 256K tokens)     | $0.40           | $1.60             | $0.04           | $0.50        | **$65**                                        |
    | Qwen3.7 Plus (> 256K tokens)     | $1.20           | $4.80             | $0.12           | $1.50        | **$65**                                        |
    | DeepSeek V4.1 Flash (Off-Peak)   | $0.15           | $0.60             | $0.003          | -            | **$105**                                       |
    | DeepSeek V4.1 Flash (Peak)       | $0.30           | $1.20             | $0.006          | -            | **$105**                                       |
    | DeepSeek V4 Pro (Off-Peak)       | $0.66           | $1.98             | $0.022          | -            | **$20**                                        |
    | DeepSeek V4 Pro (Peak)           | $1.32           | $3.96             | $0.044          | -            | **$20**                                        |
    | Hy4                              | $0.834          | $2.501            | $0.042          | -            | **$65**                                        |
    | Hy4 preview                      | $0.834          | $2.501            | $0.042          | -            | **$35**                                        |
    | Hy3                              | $0.14           | $0.58             | $0.035          | -            | **$65**                                        |
    | Grok 4.7 (≤ 200K tokens)         | $2.00           | $6.00             | $0.50           | -            | **$20**                                        |
    | Grok 4.7 (> 200K tokens)         | $4.00           | $12.00            | $1.00           | -            | **$20**                                        |
    | GPT 6 Luna (≤ 272K tokens)       | $0.10           | $0.50             | $0.01           | $0.125       | **$20**                                        |
    | GPT 6 Luna (> 272K tokens)       | $0.20           | $0.75             | $0.02           | $0.25        | **$20**                                        |
    | GPT 5.6 Luna (≤ 272K tokens)     | $0.20           | $1.20             | $0.02           | $0.25        | **$20**                                        |
    | GPT 5.6 Luna (> 272K tokens)     | $0.40           | $1.80             | $0.04           | $0.50        | **$20**                                        |
    | Claude Haiku 5.5 (≤ 100K tokens) | $0.10           | $0.50             | $0.01           | $0.125       | **$20**                                        |
    | Claude Haiku 5.5 (> 100K tokens) | $0.50           | $2.50             | $0.05           | $0.625       | **$20**                                        |
    | Gemini 4 Argon (50% off)         | ~~$4.00~~ $2.00 | ~~$20.00~~ $10.00 | ~~$0.20~~ $0.10 | -            | **$35**                                        |

  </div>
</PlanTabs>

**Crouton Alpha Free:** Free for a limited time. Not available in the European Union, Afghanistan, Belarus, China (including Hong Kong and Macau), Cambodia, Cuba, Eritrea, Ethiopia, Haiti, Iran, Iraq, Libya, Myanmar, Nicaragua, North Korea, Pakistan, Russia, Somalia, Syria, Venezuela, or Western Sahara, or in some regions within otherwise supported countries.

**Beam Free:** Free for a limited time. Not available in Angola, Belarus, Cambodia, China (including Hong Kong and Macau), Cuba, the Democratic Republic of the Congo, Equatorial Guinea, Iran, Iraq, Laos, Libya, Nigeria, North Korea, Russia, Syria, Turkmenistan, Uzbekistan, Venezuela, or the Crimea, Donetsk, and Luhansk regions of Ukraine.

**Iceman Contributor Free:** Free for a limited time.

**Gemini 4 Argon:** The 50% discount applies through November 30, 2026.

**DeepSeek V4.1 Flash / V4 Pro:** Peak hours are 01:00-04:00 and 06:00-10:00 UTC, Monday through Friday; all other hours, including weekends, are Off-Peak. [Learn more](https://api-docs.deepseek.com/quick_start/pricing/).

### Estimated requests

The tables below estimate request counts based on typical Go usage patterns. Go
Plus and Go Teams estimates scale with each model's higher usage limit.

<PlanTabs id="go-requests" label="Go plan" syncKey="go-plan">
  <div slot="go">

    | Model                      | Requests per 5 hours | Requests per week | Requests per month |
    | -------------------------- | -------------------- | ----------------- | ------------------ |
    | GLM-5.3-Flash              | 6,320                | 15,790            | 31,580             |
    | GLM-5.3                    | 220                  | 540               | 1,080              |
    | GLM-5.2                    | 880                  | 2,150             | 4,300              |
    | Kimi K3.1 Pro              | 147                  | 368               | 735                |
    | Kimi K3                    | 110                  | 250               | 490                |
    | Kimi K2.7 Code             | 1,350                | 3,380             | 6,750              |
    | LongCat-2.0                | 11,400               | 28,600            | 57,200             |
    | Step 5 Preview             | 430                  | 1,070             | 2,130              |
    | Crouton Alpha Free         | Unlimited            | Unlimited         | Unlimited          |
    | Beam Free                  | Unlimited            | Unlimited         | Unlimited          |
    | Iceman Contributor Free    | Unlimited            | Unlimited         | Unlimited          |
    | MiMo-V2.6-Flash            | 30,100               | 75,200            | 150,400            |
    | MiMo-V2.6-Pro              | 3,250                | 8,150             | 16,300             |
    | MiMo-V2.5                  | 30,100               | 75,200            | 150,400            |
    | MiMo-V2.5-Pro              | 3,250                | 8,150             | 16,300             |
    | MiniMax M3.1 Flash         | 3,880                | 9,690             | 19,380             |
    | MiniMax M3                 | 3,200                | 8,000             | 16,000             |
    | Muse Spark 1.3 Contributor | 45,300               | 113,300           | 226,600            |
    | Muse Spark 1.2 Contributor | 45,300               | 113,300           | 226,600            |
    | Qwen3.8 Max                | 160                  | 400               | 810                |
    | Qwen3.8 Flash              | 5,400                | 13,500            | 27,000             |
    | Qwen3.7 Plus               | 4,300                | 10,800            | 21,600             |
    | DeepSeek V4.1 Flash        | 43,330               | 108,330           | 216,670            |
    | DeepSeek V4 Pro            | 1,050                | 2,600             | 5,200              |
    | Hy4                        | 2,710                | 6,770             | 13,500             |
    | Hy4 preview                | 1,350                | 3,380             | 6,770              |
    | Hy3                        | 4,300                | 10,750            | 21,500             |
    | Grok 4.7                   | 169                  | 423               | 845                |
    | GPT 6 Luna                 | 4,230                | 10,560            | 21,130             |
    | GPT 5.6 Luna               | 2,050                | 5,100             | 10,250             |
    | Claude Haiku 5.5           | 3,850                | 9,620             | 19,230             |
    | Gemini 4 Argon             | 440                  | 1,080             | 2,120              |

  </div>
  <div slot="go-plus">

    | Model                      | Requests per 5 hours | Requests per week | Requests per month |
    | -------------------------- | -------------------- | ----------------- | ------------------ |
    | GLM-5.3-Flash              | 18,960               | 47,370            | 94,740             |
    | GLM-5.3                    | 1,760                | 4,320             | 8,640              |
    | GLM-5.2                    | 2,640                | 6,450             | 12,900             |
    | Kimi K3.1 Pro              | 588                  | 1,471             | 2,941              |
    | Kimi K3                    | 440                  | 1,000             | 1,960              |
    | Kimi K2.7 Code             | 4,050                | 10,140            | 20,250             |
    | LongCat-2.0                | 45,600               | 114,400           | 228,800            |
    | Step 5 Preview             | 1,720                | 4,280             | 8,520              |
    | Crouton Alpha Free         | Unlimited            | Unlimited         | Unlimited          |
    | Beam Free                  | Unlimited            | Unlimited         | Unlimited          |
    | Iceman Contributor Free    | Unlimited            | Unlimited         | Unlimited          |
    | MiMo-V2.6-Flash            | 60,200               | 150,400           | 300,800            |
    | MiMo-V2.6-Pro              | 13,000               | 32,600            | 65,200             |
    | MiMo-V2.5                  | 60,200               | 150,400           | 300,800            |
    | MiMo-V2.5-Pro              | 13,000               | 32,600            | 65,200             |
    | MiniMax M3.1 Flash         | 15,500               | 38,760            | 77,520             |
    | MiniMax M3                 | 9,600                | 24,000            | 48,000             |
    | Muse Spark 1.3 Contributor | 90,600               | 226,600           | 453,200            |
    | Muse Spark 1.2 Contributor | 90,600               | 226,600           | 453,200            |
    | Qwen3.8 Max                | 640                  | 1,600             | 3,240              |
    | Qwen3.8 Flash              | 16,200               | 40,500            | 81,000             |
    | Qwen3.7 Plus               | 12,900               | 32,400            | 64,800             |
    | DeepSeek V4.1 Flash        | 86,670               | 216,670           | 433,330            |
    | DeepSeek V4 Pro            | 4,200                | 10,400            | 20,800             |
    | Hy4                        | 10,840               | 27,080            | 54,000             |
    | Hy4 preview                | 5,400                | 13,520            | 27,080             |
    | Hy3                        | 17,200               | 43,000            | 86,000             |
    | Grok 4.7                   | 676                  | 1,692             | 3,380              |
    | GPT 6 Luna                 | 16,920               | 42,240            | 84,520             |
    | GPT 5.6 Luna               | 8,200                | 20,400            | 41,000             |
    | Claude Haiku 5.5           | 15,380               | 38,460            | 76,920             |
    | Gemini 4 Argon             | 1,760                | 4,320             | 8,480              |

  </div>
  <div slot="go-teams">

    | Model                      | Requests per 5 hours | Requests per week | Requests per month |
    | -------------------------- | -------------------- | ----------------- | ------------------ |
    | GLM-5.3-Flash              | 6,847                | 17,110            | 34,210             |
    | GLM-5.3                    | 293                  | 720               | 1,440              |
    | GLM-5.2                    | 953                  | 2,330             | 4,660              |
    | Kimi K3.1 Pro              | 196                  | 491               | 980                |
    | Kimi K3                    | 147                  | 333               | 653                |
    | Kimi K2.7 Code             | 1,462                | 3,660             | 7,310              |
    | LongCat-2.0                | 12,350               | 30,980            | 61,970             |
    | Step 5 Preview             | 573                  | 1,430             | 2,840              |
    | Crouton Alpha Free         | Unlimited            | Unlimited         | Unlimited          |
    | Beam Free                  | Unlimited            | Unlimited         | Unlimited          |
    | Iceman Contributor Free    | Unlimited            | Unlimited         | Unlimited          |
    | MiMo-V2.6-Flash            | 32,608               | 81,470            | 162,930            |
    | MiMo-V2.6-Pro              | 4,333                | 10,870            | 21,730             |
    | MiMo-V2.5                  | 32,608               | 81,470            | 162,930            |
    | MiMo-V2.5-Pro              | 4,333                | 10,870            | 21,730             |
    | MiniMax M3.1 Flash         | 4,850                | 12,110            | 24,230             |
    | MiniMax M3                 | 3,467                | 8,670             | 17,330             |
    | Muse Spark 1.3 Contributor | 49,075               | 122,740           | 245,480            |
    | Muse Spark 1.2 Contributor | 49,075               | 122,740           | 245,480            |
    | Qwen3.8 Max                | 213                  | 530               | 1,080              |
    | Qwen3.8 Flash              | 6,300                | 15,750            | 31,500             |
    | Qwen3.7 Plus               | 4,658                | 11,700            | 23,400             |
    | DeepSeek V4.1 Flash        | 45,500               | 113,750           | 227,500            |
    | DeepSeek V4 Pro            | 1,400                | 3,470             | 6,930              |
    | Hy4                        | 2,936                | 7,330             | 14,630             |
    | Hy4 preview                | 1,575                | 3,940             | 7,900              |
    | Hy3                        | 4,658                | 11,650            | 23,290             |
    | Grok 4.7                   | 225                  | 564               | 1,130              |
    | GPT 6 Luna                 | 5,640                | 14,080            | 28,170             |
    | GPT 5.6 Luna               | 2,733                | 6,800             | 13,670             |
    | Claude Haiku 5.5           | 5,133                | 12,830            | 25,640             |
    | Gemini 4 Argon             | 513                  | 1,260             | 2,470              |

  </div>
</PlanTabs>

The estimates use the following token counts per request; actual usage varies.

- Grok 4.7 — 390 input, 32,500 cached, 120 output tokens per request
- GLM-5.3-Flash — 1,000 input, 55,000 cached, 200 output tokens per request
- GLM-5.3/5.2 — 700 input, 52,000 cached, 150 output tokens per request
- GPT 6 Luna — 1,000 input, 50,000 cached, 220 output tokens per request
- GPT 5.6 Luna — 1,000 input, 50,000 cached, 220 output tokens per request
- Claude Haiku 5.5 — 1,100 input, 55,000 cached, 240 output tokens per request
- Kimi K3.1 Pro — 1,050 input, 76,500 cached, 300 output tokens per request
- Kimi K3 — 1,050 input, 76,500 cached, 300 output tokens per request
- Kimi K2.7 Code — 870 input, 55,000 cached, 200 output tokens per request
- LongCat-2.0 — 920 input, 88,900 cached, 200 output tokens per request
- Step 5 Preview — 1,000 input, 55,000 cached, 200 output tokens per request
- DeepSeek V4.1 Flash — 410 input, 71,300 cached, 310 output tokens per request
- DeepSeek V4 Pro — 750 input, 82,000 cached, 290 output tokens per request
- MiniMax M3.1 Flash — 500 input, 49,400 cached, 360 output tokens per request
- MiniMax M3 — 510 input, 56,000 cached, 190 output tokens per request
- Muse Spark 1.3 Contributor — 620 input, 71,400 cached, 300 output tokens per request
- Muse Spark 1.2 Contributor — 620 input, 71,400 cached, 300 output tokens per request
- MiMo-V2.6-Flash — 830 input, 71,500 cached, 295 output tokens per request
- MiMo-V2.6-Pro — 790 input, 86,000 cached, 305 output tokens per request
- MiMo-V2.5 — 830 input, 71,500 cached, 295 output tokens per request
- MiMo-V2.5-Pro — 790 input, 86,000 cached, 305 output tokens per request
- Qwen3.8 Max — 420 input, 66,000 cached, 200 output tokens per request
- Qwen3.8 Flash — 600 input, 58,000 cached, 200 output tokens per request
- Qwen3.7 Plus — 500 input, 57,000 cached, 190 output tokens per request
- Hy4 — 830 input, 71,500 cached, 295 output tokens per request
- Hy4 preview — 830 input, 71,500 cached, 295 output tokens per request
- Hy3 — 830 input, 71,500 cached, 295 output tokens per request

You can track your current usage in the [console](https://opencode.ai/console).

<Callout type="tip">If you reach the usage limit, you can continue using the free models.</Callout>

Usage limits may change as we learn from early usage and feedback.

---

### Usage beyond limits

If you also have credits in your Console balance, you can turn on **Extra Usage** on the
**Go** page. When enabled, Go will fall back to your [pay-as-you-go balance](/console/models#pricing)
after you've reached your usage limits instead of blocking requests.

Go Teams starts with **Extra Usage** on, and you can turn it off or on again on the **Go** page.

### Why some models have lower usage

With Go, the included monthly usage varies by model.

For most models, we make this work through bulk discounts and reserved GPU capacity. We then pass those savings on to you as higher monthly usage.

For some models, we haven't had the opportunity to negotiate a discount or host them at a lower cost, either because the model is new or because their public pricing is already discounted.

For these models, you still get a little more than if you paid the model providers directly; this is why their included monthly usage is lower.

## Endpoints

You can also access Go models through the following API endpoints. Each model is listed with its native API, but every
text model also works through the other APIs, which Console translates. See
[Base URLs](/console/harnesses#base-urls) for the full set.

<div class="docs-table-scroll" role="region" aria-label="Go model endpoints" tabIndex={0}>

| Model                      | Model ID                   | Endpoint                                                               | AI SDK Package              |
| -------------------------- | -------------------------- | ---------------------------------------------------------------------- | --------------------------- |
| Grok 4.7                   | grok-4.7                   | `https://opencode.ai/inference/go/openai/v1/responses`                 | `@ai-sdk/openai`            |
| GPT 6 Luna                 | gpt-6-luna                 | `https://opencode.ai/inference/go/openai/v1/responses`                 | `@ai-sdk/openai`            |
| GPT 5.6 Luna               | gpt-5.6-luna               | `https://opencode.ai/inference/go/openai/v1/responses`                 | `@ai-sdk/openai`            |
| Claude Haiku 5.5           | claude-haiku-5-5           | `https://opencode.ai/inference/go/anthropic/v1/messages`               | `@ai-sdk/anthropic`         |
| Gemini 4 Argon             | gemini-4-argon             | `https://opencode.ai/inference/go/google/v1beta/models/gemini-4-argon` | `@ai-sdk/google`            |
| GLM-5.3-Flash              | glm-5.3-flash              | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| GLM-5.3                    | glm-5.3                    | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| GLM-5.2                    | glm-5.2                    | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| Kimi K3.1 Pro              | kimi-k3.1-pro              | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| Kimi K3                    | kimi-k3                    | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| Kimi K2.7 Code             | kimi-k2.7-code             | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| LongCat-2.0                | longcat-2.0                | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| DeepSeek V4.1 Flash        | deepseek-v4.1-flash        | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| DeepSeek V4 Pro            | deepseek-v4-pro            | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| MiMo-V2.6-Flash            | mimo-v2.6-flash            | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| MiMo-V2.6-Pro              | mimo-v2.6-pro              | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| MiMo-V2.5                  | mimo-v2.5                  | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| MiMo-V2.5-Pro              | mimo-v2.5-pro              | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| MiniMax M3.1 Flash         | minimax-m3.1-flash         | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| MiniMax M3                 | minimax-m3                 | `https://opencode.ai/inference/go/anthropic/v1/messages`               | `@ai-sdk/anthropic`         |
| Muse Spark 1.3 Contributor | muse-spark-1.3-contributor | `https://opencode.ai/inference/go/openai/v1/responses`                 | `@ai-sdk/openai`            |
| Muse Spark 1.2 Contributor | muse-spark-1.2-contributor | `https://opencode.ai/inference/go/openai/v1/responses`                 | `@ai-sdk/openai`            |
| Qwen3.8 Max                | qwen3.8-max                | `https://opencode.ai/inference/go/anthropic/v1/messages`               | `@ai-sdk/anthropic`         |
| Qwen3.8 Flash              | qwen3.8-flash              | `https://opencode.ai/inference/go/anthropic/v1/messages`               | `@ai-sdk/anthropic`         |
| Qwen3.7 Plus               | qwen3.7-plus               | `https://opencode.ai/inference/go/anthropic/v1/messages`               | `@ai-sdk/anthropic`         |
| Hy4                        | hy4                        | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| Hy4 preview                | hy4-preview                | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| Hy3                        | hy3                        | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| Step 5 Preview             | step-5-preview             | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| Crouton Alpha Free         | crouton-alpha-free         | `https://opencode.ai/inference/go/openai/v1/responses`                 | `@ai-sdk/openai`            |
| Beam Free                  | beam-free                  | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |
| Iceman Contributor Free    | iceman-contributor-free    | `https://opencode.ai/inference/go/openai/v1/chat/completions`          | `@ai-sdk/openai-compatible` |

</div>

These AI SDK packages are for applications calling Go directly. To use Go in OpenCode, connect with `/connect` and set
the [model](/models) using the format `opencode-go/<model-id>`:

```jsonc title="opencode.jsonc"
{
  "$schema": "https://opencode.ai/config.json",
  "model": "opencode-go/kimi-k3",
}
```

### Models

Fetch the full list of available models and their metadata from the models endpoint:

```bash
curl https://opencode.ai/inference/go/v1/models
```

## Privacy

| Model                      | Model training | Data retention |
| -------------------------- | -------------- | -------------- |
| Grok 4.7                   | Not used       | 30 days        |
| GPT 6 Luna                 | Not used       | 30 days        |
| GPT 5.6 Luna               | Not used       | 30 days        |
| Claude Haiku 5.5           | Not used       | 30 days        |
| Gemini 4 Argon             | Not used       | 0 days         |
| GLM-5.3-Flash              | Not used       | 0 days         |
| GLM-5.3                    | Not used       | 0 days         |
| GLM-5.2                    | Not used       | 0 days         |
| Kimi K3.1 Pro              | Not used       | 0 days         |
| Kimi K3                    | Not used       | 0 days         |
| Kimi K2.7 Code             | Not used       | 0 days         |
| LongCat-2.0                | Not used       | 0 days         |
| MiMo-V2.6-Pro              | Not used       | 0 days         |
| MiMo-V2.6-Flash            | Not used       | 0 days         |
| MiMo-V2.5-Pro              | Not used       | 0 days         |
| MiMo-V2.5                  | Not used       | 0 days         |
| Qwen3.8 Max                | Not used       | 0 days         |
| Qwen3.8 Flash              | Not used       | 0 days         |
| Qwen3.7 Plus               | Not used       | 0 days         |
| MiniMax M3.1 Flash         | Not used       | 0 days         |
| MiniMax M3                 | Not used       | 0 days         |
| Muse Spark 1.3 Contributor | Yes            | Not ZDR        |
| Muse Spark 1.2 Contributor | Yes            | Not ZDR        |
| DeepSeek V4.1 Flash        | Not used       | 0 days\*       |
| DeepSeek V4 Pro            | Not used       | 0 days\*       |
| Hy4                        | Not used       | 0 days         |
| Hy4 preview                | Not used       | 0 days         |
| Hy3                        | Not used       | 0 days         |
| Step 5 Preview             | Not used       | 0 days         |
| Crouton Alpha Free         | Not used       | 30 days        |
| Beam Free                  | Not used       | 30 days        |
| Iceman Contributor Free    | Yes            | Not ZDR        |

- **Grok 4.7:** ZDR disables important API features that depend on stored data, including the stateful Responses API, Files and Collections, and the Batch API. [Learn more](https://docs.x.ai/developers/faq/security#what-is-zero-data-retention-zdr).
- **GPT 6 Luna / GPT 5.6 Luna:** Abuse monitoring logs are generated for all API feature usage and retained for up to 30 days. [Learn more](https://developers.openai.com/api/docs/guides/your-data#data-retention-controls-for-abuse-monitoring).
- **Claude Haiku 5.5:** Requests are retained for 30 days in accordance with [Anthropic's Data Policies](https://docs.anthropic.com/en/docs/claude-code/data-usage).
- **Muse Spark 1.3 Contributor:** Heavily discounted token pricing in exchange for permission to use your prompts and completions to train future Meta models. Availability is limited to regions permitted by Meta's [Geographic Use Policy](https://ai.developer.meta.com/legal/geographic-use-policy). [Learn more](https://dev.meta.ai/docs/pricing-rate-limits#contributor-tier).
- **Muse Spark 1.2 Contributor:** Heavily discounted token pricing in exchange for permission to use your prompts and completions to train future Meta models. Availability is limited to regions permitted by Meta's [Geographic Use Policy](https://ai.developer.meta.com/legal/geographic-use-policy). [Learn more](https://dev.meta.ai/docs/pricing-rate-limits#contributor-tier).
- **Iceman Contributor Free:** Free for a limited time in exchange for permission to use your prompts and completions to improve the model.
- **DeepSeek:** ZDR agreement is renewed monthly. The current agreement is valid through November 30, 2026.

## Background

Open models have gotten really good. They now reach performance close to proprietary models for coding tasks. Because many providers can serve them competitively, they are usually far cheaper.

However, getting reliable, low latency access to them can be difficult. Providers vary in quality and availability.

<Callout type="tip">We tested a select group of models and providers that work well with OpenCode.</Callout>

To fix this, we did a couple of things:

1. We tested a select group of open models and talked to their teams about how to best run them.
2. We worked with a few providers to make sure these were being served correctly.
3. We benchmarked the combination of the model/provider and came up with a list that we feel good recommending.

Go, Go Plus, and Go Teams all provide access to these models; choose the plan that fits how much you use them, or Go
Teams to cover your whole team.

## Goals

We created OpenCode Go to:

1. Make AI coding **accessible** to more people with a low cost subscription.
2. Provide **reliable** access to the best open coding models.
3. Curate models that are **tested and benchmarked** for coding agent use.
4. Have **no lock-in** by allowing you to use any other provider with OpenCode as well.